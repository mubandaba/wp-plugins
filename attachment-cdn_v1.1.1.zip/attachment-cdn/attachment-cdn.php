<?php  
/*
Plugin Name: 万能附件镜像存储
Plugin URI: http://www.beizigen.com
Description: 支持七牛、又拍、腾讯COS、阿里OSS等提供镜像功能的云存储。
Version: 1.1.1
Author: 背字根
Author URI: http://www.beizigen.com
*/

require_once( 'func.php' );

//删除设置
function bzg_attachment_cdn_clean() {
	bzg_attachment_cdn_delete_cron();
	update_option( 'upload_url_path', '' );
	update_option( 'upload_path', '' );
	delete_option( 'attachment_cdn_ids' );
	delete_option( 'attachment_cdn_options' );
}
register_deactivation_hook( __FILE__, 'bzg_attachment_cdn_clean' );
register_uninstall_hook( __FILE__, 'bzg_attachment_cdn_clean' );
 
function bzg_attachment_cdn_control() {
	$message = '';
	if( wp_next_scheduled( 'attachment_cdn_cron' ) )
		$message = '上传任务正在执行，请等待任务结束或重启插件以强制终止任务！';
	
	if( isset( $_POST['action'] ) && $_POST['action'] == '保存设置' ) {
		if( ! empty( $_POST['path'] ) && $_POST['path'] != 'wp-content/uploads' ) {
			$upload_path = untrailingslashit( trim( $_POST['path'] ) );
			update_option( 'upload_path', $upload_path );
		} else {
			$upload_path = 'wp-content/uploads';
			update_option( 'upload_path', '' );
		}
		
		$up_path = '';
		if( ! empty( $_POST['domain'] ) )
			$up_path = $_POST['cdnscheme'] . '://' . trim( $_POST['domain'] ) . '/' . $upload_path;
		
		update_option( 'upload_url_path', $up_path );
		
		$updates = array(
			'nohtml' => $_POST['nohtml'],
			'delfile' => $_POST['delfile'],
			'themefile' => $_POST['themefile'],
			'backupcdn' => trim($_POST['backupcdn']),
			'cdnscheme' => $_POST['cdnscheme'],
			'backupcdnscheme' => $_POST['backupcdnscheme'],
		);
		$updates = serialize($updates);
		update_option( 'attachment_cdn_options', $updates );
		$message = '保存设置成功！';
	}

	if( isset( $_POST['action'] ) && $_POST['action'] == '初始化数据' ) {
		if( get_option( 'upload_url_path' ) ) {
			$message = '任务已开始执行，执行完成会邮件通知您！';
			$start = bzg_attachment_cdn_add_cron();
			if( ! $start )
				$message = '任务正在执行，请等待任务结束或重启插件以强制终止任务！';
		} else {
			$message = '请先填写镜像域名！';
		}
	}
	if( !empty( $message ) )
		echo '<div id="message" class="updated fade" style="padding: 1em;">' . $message . '</div>';
	
	$parse_url = array();
	
	if( $upload_url_path = get_option( 'upload_url_path' ) )
		$parse_url = parse_url( $upload_url_path );
	
	$options = get_option( 'attachment_cdn_options' );
	$options = unserialize($options);
	
?>
<div class="wrap">
	<h2>WordPress附件镜像存储</h2>
	<form method="post" action="">
		<table class="form-table">
			<tbody>
				<tr>
					<th scope="row">
						<label for="nohtml">镜像正常页面</label>
					</th>
					<td>
						<select id="nohtml" name="nohtml">
							<option value="no">阻止</option>
							<option value="yes"<?php echo $options['nohtml'] == 'yes' ? ' selected="selected"' : ''; ?>>允许</option>
						</select>
						<p class="description">镜像正常页面可能导致SEO问题，一般设置为禁止，另外可以下载<a href="http://portal-static.u.qiniudn.com/temp/robots.txt" target="_blank">robots.txt</a>上传到云存储空间根目录<br />
						目前可以阻止七牛、腾讯COS镜像正常页面，如果需要支持阻止其他云存储镜像正常页面，请联系QQ80058951</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="path">上传路径</label>
					</th>
					<td>
						<input id="path" class="regular-text code" type="text" value="<?php echo get_option( 'upload_path' ) ? esc_attr( get_option( 'upload_path' ) ) : esc_attr( 'wp-content/uploads' ); ?>" name="path" />
						<p class="description">一般使用WordPress默认设置，即wp-content/uploads</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="domain">CDN域名</label>
					</th>
					<td>
						<select id="cdnscheme" name="cdnscheme">
							<option value="http">http://</option>
							<option value="https"<?php echo $options['cdnscheme'] == 'https' ? ' selected="selected"' : ''; ?>>https://</option>
						</select>
						<input id="domain" class="regular-text code" type="text" value="<?php echo ! empty( $parse_url['host'] ) ? $parse_url['host'] : ''; ?>" name="domain" />
						<p class="description">七牛、又拍、腾讯COS等提供的域名或您在这些平台绑定的域名，例如：static.beizigen.com</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="backupcdn">备用CDN</label>
					</th>
					<td>
						<select id="backupcdnscheme" name="backupcdnscheme">
							<option value="http">http://</option>
							<option value="https"<?php echo $options['backupcdnscheme'] == 'https' ? ' selected="selected"' : ''; ?>>https://</option>
						</select>
						<input id="backupcdn" class="regular-text code" type="text" value="<?php echo ! empty( $options['backupcdn'] ) ? $options['backupcdn'] : ''; ?>" name="backupcdn" />
						<p class="description">可不用填写，同CDN域名设置，上传的附件会同步到该空间，但不会在网站调用，用于附件备份</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="themefile">存储主题附件</label>
					</th>
					<td>
						<select id="themefile" name="themefile">
							<option value="no">否</option>
							<option value="yes"<?php echo $options['themefile'] == 'yes' ? ' selected="selected"' : ''; ?>>是</option>
						</select>
						<p class="description">将主题附件、WordPress自带JS和CSS（例如jQuery和Dashicons图标）自动同步到云存储</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="delfile">删除本地文件</label>
					</th>
					<td>
						<select id="delfile" name="delfile">
							<option value="no">否</option>
							<option value="yes"<?php echo $options['delfile'] == 'yes' ? ' selected="selected"' : ''; ?>>是</option>
						</select>
						<p class="description">不推荐，多一份备份多一份安全</p>
					</td>
				</tr>
			</tbody>		
		</table>
		<p><input class="button-primary" type="submit" name="action" value="保存设置" /></p>
		<p class="description">如果是第一次安装使用，可以使用初始化功能将现有图片全部同步到云存储</p>
		<p class="description">在点击初始化数据按钮后，为了确保任务顺利执行，请点击<a href="<?php bloginfo ( 'url' ); ?>/wp-cron.php" target="_blank">访问WordPress定时任务加载页面</a></p>
		<p><input class="button" type="submit" name="action" value="初始化数据" /></p>

	</form>

</div>

<?php
} 
//添加菜单
function bzg_attachment_cdn_menu() {
	if ( function_exists( 'add_options_page' ) )
		add_options_page( 'WordPress附件镜像存储', '附件存储', 'administrator', 'attachment-cdn', 'bzg_attachment_cdn_control' );
}
add_action( 'admin_menu', 'bzg_attachment_cdn_menu' );

function bzg_attachment_cdn_settings_link( $action_links, $plugin_file ) {
	if( $plugin_file == plugin_basename( __FILE__ ) ){
		$settings_link = '<a href="options-general.php?page=attachment-cdn">设置</a>';
		array_unshift( $action_links, $settings_link );
	}
	return $action_links;
}
add_filter( 'plugin_action_links', 'bzg_attachment_cdn_settings_link', 10, 2 );
?>