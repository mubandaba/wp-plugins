<?php include 'public-header.php'; ?>

        <div class="uk-grid uk-grid-stack" uk-grid>
            <div class="uk-width-1-1@sr">
                <div class="uk-first-column">
                    <div class="el-item uk-border-rounded uk-overflow-hidden uk-card uk-card-default uk-card-hover uk-scrollspy-inview uk-animation-slide-bottom-medium">

                        <header class="wextoolbox_header uk-light uk-padding uk-width-1-1@s">
                            <div class="uk-h1 uk-margin-remove-bottom uk-display-inline-block">
                                SEO优化
                            </div>
                            <div class="uk-text-meta uk-display-inline-block ">
                                WordPress小宇宙提供功能
                            </div>


                        </header>

                        <main>



                            <div class="uk-grid-collapse" uk-grid>
                                <div class="uk-width-1-6">
                                    <ul class="wextoolbox_aside_menu" uk-tab="connect: #wextoolbox_optimize_content; animation: uk-animation-fade">
                                        <li class="uk-text-center"><a href="">首页TDK</a></li>
                                        <li class="uk-text-center"><a href="">分类页TDK</a></li>
                                        <li class="uk-text-center"><a href="">文章页TDK</a></li>
                                        <li class="uk-text-center"><a href="">链接提交</a></li>
                                    </ul>

                                </div>
                                <div class="uk-width-expand wextoolbox_optimize_content_container">
                                    <ul id="wextoolbox_optimize_content"  class="uk-switcher">
                                        <li>
                                            <?php
                                            $option_array = array(
                                                'id'=>'front_page_TDK',
                                                'title'=>'首页TDK',
                                                'options'=>array(

                                                    array(
                                                        'id'=>'title',
                                                        'title'=>'首页title',
                                                        'category'=>'input',
                                                        'placeholder'=>'首页title',
                                                        'handles'=>array(

                                                            array(
                                                                'id'=>'site_name',
                                                                'color'=>'orange',
                                                                'title'=>'站点名',
                                                            ),
                                                            array(
                                                                'id'=>'site_description',
                                                                'color'=>'blue',
                                                                'title'=>'站点描述',
                                                            ),
                                                        ),
                                                    ),

                                                    array(
                                                        'id'=>'keywords',
                                                        'title'=>'首页keywords',
                                                        'category'=>'input',
                                                        'placeholder'=>'首页keywords',
                                                        'handles'=>array(

                                                            array(
                                                                'id'=>'site_name',
                                                                'color'=>'orange',
                                                                'title'=>'站点名',
                                                            ),
                                                            array(
                                                                'id'=>'site_description',
                                                                'color'=>'blue',
                                                                'title'=>'站点描述',
                                                            ),
                                                        ),
                                                    ),
                                                    array(
                                                        'id'=>'description',
                                                        'title'=>'首页description',
                                                        'category'=>'textarea',
                                                        'row'=>9,
                                                        'placeholder'=>'首页description',
                                                        'handles'=>array(

                                                            array(
                                                                'id'=>'site_name',
                                                                'color'=>'orange',
                                                                'title'=>'站点名',
                                                            ),
                                                            array(
                                                                'id'=>'site_description',
                                                                'color'=>'blue',
                                                                'title'=>'站点描述',
                                                            ),

                                                        ),
                                                    ),

                                                ),

                                            );

                                            WPXYZ_input_form($option_array);
                                            ?>
                                        </li>
                                        <li>
                                            <?php
                                            $option_array = array(
                                                'id'=>'archive_page_TDK',
                                                'title'=>'分类页TDK',
                                                'options'=>array(

                                                    array(
                                                        'id'=>'title',
                                                        'title'=>'分类页title',
                                                        'category'=>'input',
                                                        'placeholder'=>'分类页title',
                                                        'handles'=>array(
                                                            array(
                                                                'id'=>'archive_title',
                                                                'color'=>'green',
                                                                'title'=>'分类名',
                                                            ),
                                                            array(
                                                                'id'=>'archive_description',
                                                                'color'=>'',
                                                                'title'=>'分类图像描述',
                                                            ),
                                                            array(
                                                                'id'=>'site_name',
                                                                'color'=>'orange',
                                                                'title'=>'站点名',
                                                            ),
                                                            array(
                                                                'id'=>'site_description',
                                                                'color'=>'blue',
                                                                'title'=>'站点描述',
                                                            ),

                                                        ),
                                                    ),

                                                    array(
                                                        'id'=>'keywords',
                                                        'title'=>'分类页keywords',
                                                        'category'=>'input',
                                                        'placeholder'=>'分类页keywords',
                                                        'handles'=>array(
                                                            array(
                                                                'id'=>'archive_title',
                                                                'color'=>'green',
                                                                'title'=>'分类名',
                                                            ),
                                                            array(
                                                                'id'=>'archive_description',
                                                                'color'=>'',
                                                                'title'=>'分类图像描述',
                                                            ),
                                                            array(
                                                                'id'=>'site_name',
                                                                'color'=>'orange',
                                                                'title'=>'站点名',
                                                            ),
                                                            array(
                                                                'id'=>'site_description',
                                                                'color'=>'blue',
                                                                'title'=>'站点描述',
                                                            ),

                                                        ),
                                                        ),

                                                    array(
                                                        'id'=>'description',
                                                        'title'=>'分类页description',
                                                        'category'=>'textarea',
                                                        'row'=>9,
                                                        'placeholder'=>'分类页description',
                                                        'handles'=>array(
                                                            array(
                                                                'id'=>'archive_title',
                                                                'color'=>'green',
                                                                'title'=>'分类名',
                                                            ),
                                                            array(
                                                                'id'=>'archive_description',
                                                                'color'=>'',
                                                                'title'=>'分类图像描述',
                                                            ),
                                                            array(
                                                                'id'=>'site_name',
                                                                'color'=>'orange',
                                                                'title'=>'站点名',
                                                            ),
                                                            array(
                                                                'id'=>'site_description',
                                                                'color'=>'blue',
                                                                'title'=>'站点描述',
                                                            ),

                                                        ),
                                                    ),
                                                ),
                                            );
                                            WPXYZ_input_form($option_array);
                                            ?>
                                        </li>
                                        <li>
                                            <?php
                                            $option_array = array(
                                                'id'=>'single_page_TDK',
                                                'title'=>'文章页TDK',
                                                'options'=>array(

                                                    array(
                                                        'id'=>'title',
                                                        'title'=>'文章页title',
                                                        'category'=>'input',
                                                        'placeholder'=>'文章页title',
                                                        'handles'=>array(
                                                            array(
                                                                'id'=>'single_title',
                                                                'color'=>'green',
                                                                'title'=>'文章名',
                                                            ),
                                                            array(
                                                                'id'=>'single_categories',
                                                                'color'=>'',
                                                                'title'=>'文章分类',
                                                            ),
                                                            array(
                                                                'id'=>'site_name',
                                                                'color'=>'orange',
                                                                'title'=>'站点名',
                                                            ),
                                                            array(
                                                                'id'=>'site_description',
                                                                'color'=>'blue',
                                                                'title'=>'站点描述',
                                                            ),

                                                        ),
                                                    ),
                                                    array(
                                                        'id'=>'keywords',
                                                        'title'=>'文章页keywords',
                                                        'category'=>'input',
                                                        'placeholder'=>'文章页keywords',
                                                        'handles'=>array(
                                                            array(
                                                                'id'=>'single_title',
                                                                'color'=>'green',
                                                                'title'=>'文章名',
                                                            ),
                                                            array(
                                                                'id'=>'single_categories',
                                                                'color'=>'',
                                                                'title'=>'文章分类',
                                                            ),
                                                            array(
                                                                'id'=>'site_name',
                                                                'color'=>'orange',
                                                                'title'=>'站点名',
                                                            ),
                                                            array(
                                                                'id'=>'site_description',
                                                                'color'=>'blue',
                                                                'title'=>'站点描述',
                                                            ),

                                                        ),

                                                    ),
                                                    array(
                                                        'id'=>'description',
                                                        'title'=>'文章页description',
                                                        'category'=>'textarea',
                                                        'row'=>9,
                                                        'placeholder'=>'文章页description',
                                                        'handles'=>array(
                                                            array(
                                                                'id'=>'single_title',
                                                                'color'=>'green',
                                                                'title'=>'文章名',
                                                            ),
                                                            array(
                                                                'id'=>'single_categories',
                                                                'color'=>'',
                                                                'title'=>'文章分类',
                                                            ),
                                                            array(
                                                                'id'=>'site_name',
                                                                'color'=>'orange',
                                                                'title'=>'站点名',
                                                            ),
                                                            array(
                                                                'id'=>'site_description',
                                                                'color'=>'blue',
                                                                'title'=>'站点描述',
                                                            ),

                                                        ),

                                                    ),

                                                ),
                                            );
                                            WPXYZ_input_form($option_array);
                                            ?>

                                        </li>

                                        <li>
                                            <table class="uk-table uk-table-striped">
                                                <thead>
                                                <tr>
                                                    <th>链接提交</th>
                                                </tr>

                                                </thead>
                                                <tbody>

                                                <tr>
                                                    <td>
                                                        <div>
                                                            快速收录
                                                        </div>
                                                        <small class="option_desc">
                                                            快速收录工具可以向百度搜索主动推送资源，缩短爬虫发现网站链接的时间，对于高实效性内容推荐使用快速收录工具，实时向搜索推送资源
                                                        </small>
                                                    </td>
                                                    <td class="uk-text-right">
                                                        <?php
                                                        $api = get_option('wpxyz_baidu_fast_api');
                                                        if(!$api){
                                                            echo '<a href="#fast_submit_modal_1" uk-toggle class="uk-button uk-button-primary uk-button-small">初始化</a>';
                                                        }else{
                                                            echo '<a href="#fast_submit_modal_2" uk-toggle class="uk-button uk-button-primary uk-button-small">提交</a>';
                                                        }?>

                                                    </td>
                                                    <td>
                                                    </td>
                                                </tr>
                                                <tr>

                                                    <td>
                                                        <div>
                                                            普通收录
                                                        </div>
                                                        <small class="option_desc">
                                                            普通收录工具可以向百度搜索主动推送资源，缩短爬虫发现网站链接的时间，每日至多提交10万条有价值的内容
                                                        </small>
                                                    </td>
                                                    <td class="uk-text-right">
                                                        <a href="#<?php
                                                        $api = get_option('wpxyz_baidu_current_api');
                                                        if(!$api){
                                                            echo 'current_api_submit_modal_1';
                                                        }else{
                                                            echo 'current_api_submit_modal_2';
                                                        }?>" uk-toggle class="uk-button uk-button-primary uk-button-small">
                                                            <?php
                                                            $api = get_option('wpxyz_baidu_current_api');
                                                            if(!$api){
                                                                echo '初始化';
                                                            }else{
                                                                echo '提交';
                                                            }?>
                                                        </a>
                                                    </td>
                                                    <td>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div>
                                                             SITEMAP
                                                        </div>
                                                        <small class="option_desc">
                                                            您可以定期将网站链接放到Sitemap中，然后将Sitemap提交给百度。百度会周期性的抓取检查您提交的Sitemap， <br>对其中的链接进行处理，但收录速度慢于API推送
                                                        </small>
                                                    </td>
                                                    <td class="uk-text-right">
                                                        <a id="sitemap_button" class="uk-button uk-button-primary uk-button-small">
                                                            生成
                                                        </a>
                                                    </td>
                                                </tr>



                                                </tbody>
                                            </table>
                                        </li>


                                    </ul>
                                </div>

                            </div>


                        </main>
                    </div>
                </div>
            </div>
        </div>

<!--api设置 start-->
<div id="fast_submit_modal_1" class="uk-flex-top" uk-modal>
            <div class="uk-modal-dialog uk-modal-body uk-margin-auto-vertical">

                <button class="uk-modal-close-outside" type="button" uk-close></button>
                <h2 class="uk-h5">
                    百度快速提交
                </h2>
                <form>
                    <fieldset class="uk-fieldset">

                        <div class="uk-margin">
                            <input id="fast_api_input" class="uk-input" type="text" placeholder="接口调用地址" value="<?php echo get_option('wpxyz_baidu_fast_api')?>">
                        </div>

                        <div class="uk-margin-top">
                            <button id="fast_api_save" class="uk-button uk-button-primary uk-border-pill uk-button-small" type="button">
                                保存
                            </button>
                        </div>

                    </fieldset>
                </form>

            </div>
        </div>
<div id="current_api_submit_modal_1" class="uk-flex-top" uk-modal>
    <div class="uk-modal-dialog uk-modal-body uk-margin-auto-vertical">

        <button class="uk-modal-close-outside" type="button" uk-close></button>
        <h2 class="uk-h5">
            百度普通收录
        </h2>
        <form>
            <fieldset class="uk-fieldset">

                <div class="uk-margin">
                    <input id="current_api_input" class="uk-input" type="text" placeholder="接口调用地址" value="<?php echo get_option('wpxyz_baidu_current_api')?>">
                </div>

                <div class="uk-margin-top">
                    <button id="current_api_save" class="uk-button uk-button-primary uk-border-pill uk-button-small" type="button">
                        保存
                    </button>
                </div>

            </fieldset>
        </form>
    </div>
</div>
<!--api设置 end-->

<div id="fast_submit_modal_2" class="uk-flex-top" uk-modal>
            <div class="uk-modal-dialog uk-modal-body uk-margin-auto-vertical">

                <button class="uk-modal-close-outside" type="button" uk-close></button>
                <h2 class="uk-h5">
                    自定义URL快速提交
                    <small style="opacity: 0.6 ;font-size: 10px">
                        (一行一个URL)
                    </small>
                </h2>
                <div class="uk-position-top-right uk-padding-small">
                    <ul class="uk-iconnav  uk-padding-small">
                        <li>
                            <a href="#fast_submit_modal_1" uk-toggle  class="uk-display-inline-block uk-margin-small-bottom" style="opacity: 0.6" uk-tooltip="修改API" >
                                <svg class="icon" viewBox="0 0 1105 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2629" width="20" height="20"><path d="M358.970906 945.384648c-2.080729 0-4.251924-0.271399-6.332652-0.904665-62.33139-17.279094-119.868057-50.389817-166.458283-95.894446-4.885189-4.794722-7.41825-11.48924-7.056384-18.274225 0.361866-6.784984 3.709125-13.208103 9.137112-17.36956 29.763465-23.159413 37.995912-65.045383 19.178889-97.522842-18.90749-32.567925-59.25553-46.318827-94.085117-32.386992-6.332652 2.623527-13.569969 2.352128-19.631221-0.814198-6.061253-3.07586-10.584576-8.68478-12.212972-15.288831-7.961048-31.391861-11.941572-63.59792-11.941572-95.803979 0-32.115593 3.980524-64.321652 11.941572-95.803979 1.718863-6.604051 6.151719-12.212972 12.212972-15.379298 6.061253-3.166326 13.208103-3.437725 19.631221-0.814198 34.73912 14.112767 75.08716 0.271399 93.99465-32.296526 18.817023-32.386992 10.584576-74.363429-19.178889-97.522842-5.427987-4.251924-8.68478-10.584576-9.137112-17.36956-0.361866-6.784984 2.171195-13.479502 7.056384-18.274225 46.590226-45.504628 104.21736-78.705819 166.458283-95.894446 6.694518-1.718863 13.660435-0.633265 19.359822 3.07586 5.699387 3.799591 9.498978 9.770377 10.403643 16.555362 5.066122 37.181714 37.272181 65.226316 74.815761 65.226316 26.868538 0 65.13585-39.986175 75.08716-57.536667-0.723732-3.618658-0.542799-7.508716 0.542799-11.308307 3.799591-12.484371 17.007694-19.450289 29.401599-15.922097 0 0 0 0 0.090466 0l0 0 0 0c64.954917 19.359822 120.772722 51.656348 165.915484 95.713513 4.885189 4.794722 7.508716 11.48924 7.14685 18.274225-0.361866 6.784984-3.709125 13.117636-9.137112 17.36956-29.672998 23.159413-37.995912 65.045383-19.178889 97.522842 18.90749 32.567925 59.345997 46.49976 94.085117 32.296526 6.332652-2.623527 13.479502-2.352128 19.631221 0.814198 6.151719 3.07586 10.584576 8.68478 12.212972 15.379298 7.961048 31.482327 11.941572 63.688387 11.941572 95.713513s-4.070991 64.231185-11.941572 95.803979c-1.718863 6.604051-6.151719 12.212972-12.212972 15.288831-6.151719 3.166326-13.208103 3.437725-19.631221 0.814198-34.73912-14.022301-75.177627-0.180933-94.085117 32.386992-18.817023 32.386992-10.584576 74.363429 19.178889 97.522842 5.427987 4.161457 8.68478 10.494109 9.137112 17.36956s-2.171195 13.479502-7.14685 18.274225c-46.49976 45.414162-104.036427 78.615352-166.458283 95.894446-6.604051 1.809329-13.660435 0.723732-19.269356-3.07586-5.699387-3.799591-9.498978-9.860844-10.494109-16.555362-5.066122-37.181714-37.181714-65.226316-74.815761-65.226316-37.54358 0-69.749639 28.044602-74.815761 65.226316-0.904665 6.784984-4.704256 12.755771-10.403643 16.555362C368.108019 944.118117 363.584696 945.384648 358.970906 945.384648zM237.203053 831.035045c31.210928 26.325739 66.945179 46.952092 105.212491 60.612527 17.731426-46.680692 63.145588-79.339084 114.892402-79.339084 51.746814 0 97.160976 32.658391 114.892402 79.339084 38.357778-13.660435 74.001563-34.286788 105.212491-60.612527-31.572794-38.900577-37.181714-94.537449-11.217841-139.318346 25.873407-44.69043 76.896489-67.397511 126.110243-59.888795 3.618658-20.083554 5.337521-40.438507 5.337521-60.612527 0-20.17402-1.809329-40.438507-5.337521-60.612527-49.03282 7.961048-100.146369-15.198365-126.110243-59.888795-25.963874-44.69043-20.354953-100.327302 11.217841-139.227879-30.487196-25.692474-65.950048-45.956961-105.75529-60.522061-20.17402 33.110724-68.935441 79.158151-114.349603 79.158151-51.656348 0-97.07051-32.658391-114.892402-79.339084-38.267312 13.569969-74.001563 34.196321-105.212491 60.702993 31.572794 38.900577 37.181714 94.537449 11.217841 139.227879-25.963874 44.69043-76.62509 67.668911-126.019776 59.888795-3.618658 20.083554-5.427987 40.34804-5.427987 60.612527 0 20.264487 1.809329 40.528973 5.427987 60.612527 49.123287-7.780115 100.146369 15.198365 126.110243 59.979262C274.294301 736.407129 268.775847 792.134468 237.203053 831.035045z" p-id="2630" fill="#707070"></path><path d="M457.21748 694.24976c-67.759377 0-122.943917-55.18454-122.943917-123.034383s55.18454-122.943917 122.943917-122.943917c67.759377 0 122.943917 55.18454 122.943917 122.943917S524.976857 694.24976 457.21748 694.24976zM457.21748 495.675884c-41.705037 0-75.629959 33.924922-75.629959 75.629959s33.924922 75.629959 75.629959 75.629959c41.705037 0 75.539493-33.924922 75.539493-75.629959S498.922517 495.675884 457.21748 495.675884z" p-id="2631" fill="#707070"></path></svg>
                            </a>
                        </li>
                    </ul>
                </div>
                <form>
                    <fieldset class="uk-fieldset">

                        <div class="uk-margin uk-position-relative">
                            <textarea id="fast_submit_input" class="uk-textarea has_tip" rows="5" placeholder=''></textarea>


                            <div class="uk-position-absolute uk-position-top-left uk-padding-small" style="z-index: -1;padding-top: 4px">
                                示例如下：
                                <br>https://www.utheme.cn/1.html
                                <br>https://www.utheme.cn/2.html
                                <br>https://www.utheme.cn/3.html
                            </div>
                        </div>

                        <div class="uk-margin-top">
                            <button id="fast_submit_modal_2_submit" class="uk-button uk-button-primary uk-border-pill uk-button-small" type="button">
                                提交
                            </button>
                        </div>

                    </fieldset>
                </form>
            </div>
        </div>
<div id="current_api_submit_modal_2" class="uk-flex-top" uk-modal>
            <div class="uk-modal-dialog uk-modal-body uk-margin-auto-vertical">

                <button class="uk-modal-close-outside" type="button" uk-close></button>
                <h2 class="uk-h5">
                    百度普通收录
                </h2>
                <div >

                    <ul class="uk-switcher uk-margin">
                        <li class="uk-active" >

                            <table class="uk-table uk-table-striped">
                                <tbody>
                                <tr>
                                    <td>
                                        提交所有文章
                                    </td>
                                    <td class="uk-text-right">
                                        <button id="current_api_submit_single" class="uk-button uk-button-primary uk-border-pill uk-button-small" type="button">
                                            提交
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        提交所有分类页
                                    </td>
                                    <td class="uk-text-right">
                                        <button id="current_api_submit_archive" class="uk-button uk-button-primary uk-border-pill uk-button-small" type="button">
                                            提交
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        自定义URL提交
                                    </td>
                                    <td class="uk-text-right">
                                        <a href="#current_api_submit_modal_3" uk-toggle class="uk-button uk-button-primary uk-border-pill uk-button-small" type="button">
                                            提交
                                        </a>
                                    </td>
                                </tr>
                                </tbody>
                            </table>

                        </li>

                    </ul>
                    <div class="uk-position-top-right uk-padding-small">
                        <ul class="uk-iconnav  uk-padding-small">
                            <li>
                                <a href="#current_api_submit_modal_1" uk-toggle  class="uk-display-inline-block uk-margin-small-bottom" style="opacity: 0.6" uk-tooltip="修改API" >
                                    <svg class="icon" viewBox="0 0 1105 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2629" width="20" height="20"><path d="M358.970906 945.384648c-2.080729 0-4.251924-0.271399-6.332652-0.904665-62.33139-17.279094-119.868057-50.389817-166.458283-95.894446-4.885189-4.794722-7.41825-11.48924-7.056384-18.274225 0.361866-6.784984 3.709125-13.208103 9.137112-17.36956 29.763465-23.159413 37.995912-65.045383 19.178889-97.522842-18.90749-32.567925-59.25553-46.318827-94.085117-32.386992-6.332652 2.623527-13.569969 2.352128-19.631221-0.814198-6.061253-3.07586-10.584576-8.68478-12.212972-15.288831-7.961048-31.391861-11.941572-63.59792-11.941572-95.803979 0-32.115593 3.980524-64.321652 11.941572-95.803979 1.718863-6.604051 6.151719-12.212972 12.212972-15.379298 6.061253-3.166326 13.208103-3.437725 19.631221-0.814198 34.73912 14.112767 75.08716 0.271399 93.99465-32.296526 18.817023-32.386992 10.584576-74.363429-19.178889-97.522842-5.427987-4.251924-8.68478-10.584576-9.137112-17.36956-0.361866-6.784984 2.171195-13.479502 7.056384-18.274225 46.590226-45.504628 104.21736-78.705819 166.458283-95.894446 6.694518-1.718863 13.660435-0.633265 19.359822 3.07586 5.699387 3.799591 9.498978 9.770377 10.403643 16.555362 5.066122 37.181714 37.272181 65.226316 74.815761 65.226316 26.868538 0 65.13585-39.986175 75.08716-57.536667-0.723732-3.618658-0.542799-7.508716 0.542799-11.308307 3.799591-12.484371 17.007694-19.450289 29.401599-15.922097 0 0 0 0 0.090466 0l0 0 0 0c64.954917 19.359822 120.772722 51.656348 165.915484 95.713513 4.885189 4.794722 7.508716 11.48924 7.14685 18.274225-0.361866 6.784984-3.709125 13.117636-9.137112 17.36956-29.672998 23.159413-37.995912 65.045383-19.178889 97.522842 18.90749 32.567925 59.345997 46.49976 94.085117 32.296526 6.332652-2.623527 13.479502-2.352128 19.631221 0.814198 6.151719 3.07586 10.584576 8.68478 12.212972 15.379298 7.961048 31.482327 11.941572 63.688387 11.941572 95.713513s-4.070991 64.231185-11.941572 95.803979c-1.718863 6.604051-6.151719 12.212972-12.212972 15.288831-6.151719 3.166326-13.208103 3.437725-19.631221 0.814198-34.73912-14.022301-75.177627-0.180933-94.085117 32.386992-18.817023 32.386992-10.584576 74.363429 19.178889 97.522842 5.427987 4.161457 8.68478 10.494109 9.137112 17.36956s-2.171195 13.479502-7.14685 18.274225c-46.49976 45.414162-104.036427 78.615352-166.458283 95.894446-6.604051 1.809329-13.660435 0.723732-19.269356-3.07586-5.699387-3.799591-9.498978-9.860844-10.494109-16.555362-5.066122-37.181714-37.181714-65.226316-74.815761-65.226316-37.54358 0-69.749639 28.044602-74.815761 65.226316-0.904665 6.784984-4.704256 12.755771-10.403643 16.555362C368.108019 944.118117 363.584696 945.384648 358.970906 945.384648zM237.203053 831.035045c31.210928 26.325739 66.945179 46.952092 105.212491 60.612527 17.731426-46.680692 63.145588-79.339084 114.892402-79.339084 51.746814 0 97.160976 32.658391 114.892402 79.339084 38.357778-13.660435 74.001563-34.286788 105.212491-60.612527-31.572794-38.900577-37.181714-94.537449-11.217841-139.318346 25.873407-44.69043 76.896489-67.397511 126.110243-59.888795 3.618658-20.083554 5.337521-40.438507 5.337521-60.612527 0-20.17402-1.809329-40.438507-5.337521-60.612527-49.03282 7.961048-100.146369-15.198365-126.110243-59.888795-25.963874-44.69043-20.354953-100.327302 11.217841-139.227879-30.487196-25.692474-65.950048-45.956961-105.75529-60.522061-20.17402 33.110724-68.935441 79.158151-114.349603 79.158151-51.656348 0-97.07051-32.658391-114.892402-79.339084-38.267312 13.569969-74.001563 34.196321-105.212491 60.702993 31.572794 38.900577 37.181714 94.537449 11.217841 139.227879-25.963874 44.69043-76.62509 67.668911-126.019776 59.888795-3.618658 20.083554-5.427987 40.34804-5.427987 60.612527 0 20.264487 1.809329 40.528973 5.427987 60.612527 49.123287-7.780115 100.146369 15.198365 126.110243 59.979262C274.294301 736.407129 268.775847 792.134468 237.203053 831.035045z" p-id="2630" fill="#707070"></path><path d="M457.21748 694.24976c-67.759377 0-122.943917-55.18454-122.943917-123.034383s55.18454-122.943917 122.943917-122.943917c67.759377 0 122.943917 55.18454 122.943917 122.943917S524.976857 694.24976 457.21748 694.24976zM457.21748 495.675884c-41.705037 0-75.629959 33.924922-75.629959 75.629959s33.924922 75.629959 75.629959 75.629959c41.705037 0 75.539493-33.924922 75.539493-75.629959S498.922517 495.675884 457.21748 495.675884z" p-id="2631" fill="#707070"></path></svg>
                                </a>
                            </li>
                        </ul>
                    </div>

                </div>


            </div>
        </div>
<div id="current_api_submit_modal_3" class="uk-flex-top" uk-modal>
            <div class="uk-modal-dialog uk-modal-body uk-margin-auto-vertical">

                <button class="uk-modal-close-outside" type="button" uk-close></button>
                <h2 class="uk-h5">
                    自定义URL提交
                    <small style="opacity: 0.6 ;font-size: 10px">
                        (一行一个URL)
                    </small>
                </h2>
                <form>
                    <fieldset class="uk-fieldset">

                        <div class="uk-margin uk-position-relative">
                            <textarea id="current_submit_input"  style="height: 300px;opacity: 0.5" class="uk-textarea has_tip" rows="5" placeholder=''></textarea>

                        </div>

                        <div class="uk-margin-top">
                            <button id="current_submit_modal_3_submit" class="uk-button uk-button-primary uk-border-pill uk-button-small" type="button">
                                提交
                            </button>
                        </div>

                    </fieldset>
                </form>
            </div>
        </div>

<?php include 'public-active.php'; ?>
<?php include 'public-footer.php'; ?>

