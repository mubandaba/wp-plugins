﻿=== wp-hatmore-localpic ===
Contributors: hatmore
Donate link: http://hatmore.com/
Tags: post, img
Requires at least: 3.3
Tested up to: 3.5
Stable tag: Local storage of remote images
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Local storage of remote images (远程图片存储到本地，同时更正图片链接地址。)


== Description ==
The remote images stored in the local, while correct picture link address. (远程图片下载到本地，同时更正图片链接地址。)

== Installation ==

1. Upload `wp-hatmore-localpic` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==
= 2.1 =
= 1.0 =
* First version