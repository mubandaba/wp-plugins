<?php include 'public-header.php'; ?>

        <div class="uk-grid uk-grid-stack uk-first-column" uk-grid>
            <div class="uk-width-1-1@s uk-first-column">
                <div class="uk-first-column">
                    <div class="el-item uk-border-rounded uk-overflow-hidden uk-card uk-card-default uk-card-hover uk-scrollspy-inview uk-animation-slide-bottom-medium">

                        <header class="wextoolbox_header uk-light uk-padding uk-width-1-1@s uk-first-column">
                            <div class="uk-h1 uk-margin-remove-bottom uk-display-inline-block">
                                优化加速
                            </div>
                            <div class="uk-text-meta uk-display-inline-block ">
                                WordPress小宇宙提供功能
                            </div>


                        </header>

                        <main>


                            <div class="uk-grid-collapse" uk-grid>
                                <div class="uk-width-1-6">
                                    <ul class="wextoolbox_aside_menu" uk-tab="connect: #wextoolbox_optimize_content; animation: uk-animation-fade">
                                        <li class="uk-text-center"><a href="">服务器状态</a></li>
                                        <li class="uk-text-center"><a href="">前端优化</a></li>
                                        <li class="uk-text-center"><a href="">系统优化</a></li>
                                    </ul>


                                </div>
                                <div class="uk-width-expand wextoolbox_optimize_content_container">
                                    <ul id="wextoolbox_optimize_content"  class="uk-switcher">
                                    <li class="uk-height-large">
                                        <table class="uk-table uk-table-striped">
                                            <thead>

                                            <tr>
                                                <th>服务器状态</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td>内存情况</td>
                                                <td>已使用
                                                    <?php
                                                    $memory  = ( ! function_exists('memory_get_usage')) ? '0' : round(memory_get_usage()/1024/1024, 2).'MB';
                                                    echo $memory; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>WP可使用内存上限</td>
                                                <td><?php echo WP_MEMORY_LIMIT;?> <a href="https://weixingv.com/724.html">如何修改</a></td>
                                            </tr>
                                            <tr>
                                                <td>WP管理员可使用内存上限</td>
                                                <td><?php echo WP_MAX_MEMORY_LIMIT;?> <a href="https://weixingv.com/724.html">如何修改</a></td>
                                            </tr>
                                            <tr>
                                                <td>服务器软件</td>
                                                <td><?php global $is_apache, $is_nginx, $is_iis; if($is_apache){ echo 'Apache';}elseif($is_nginx){echo 'nginx';}elseif($is_iis){echo 'IIS';}else{echo 'kangle';}?></td>
                                            </tr>

                                            <tr>
                                                <td>服务器系统</td>
                                                <td><?php echo php_uname();?></td>
                                            </tr>
                                            <tr>
                                                <td>MySQL</td>
                                                <td><?php global $wpdb,$required_mysql_version; echo $wpdb->db_version();?>（最低要求：5.0）</td>
                                            </tr>
                                            <tr>
                                                <td>PHP	</td>
                                                <td><?php echo PHP_VERSION;  ?>（最低要求：5.6.20）</td>
                                            </tr>
                                            <tr>
                                                <td>WordPress</td>
                                                <td><?php global $wp_version; echo $wp_version;?></td>
                                            </tr>
                                            <tr>
                                                <td>PHP	</td>
                                                <td><?php echo PHP_VERSION;?></td>
                                            </tr>
                                            <tr>
                                                <td>文档根目录</td>
                                                <td><?php echo $_SERVER['DOCUMENT_ROOT'];?></td>
                                            </tr>


                                            </tbody>
                                        </table>

                                    </li>
                                    <li>
                                        <table class="uk-table uk-table-striped">
                                            <thead>

                                            <tr>
                                                <th>前端优化</th>
                                            </tr>
                                            </thead>
                                            <tbody>

                                        <?php
                                        $args =[
                                            array(
                                                'id'    => 'dnsprefetch_switcher',
                                                'type'  => 'switcher',
                                                'title' => '禁用s.w.org和dns-prefetch',
                                                'default'  => false,

                                            ),
                                            array(
                                                'id'    => 'wpgenerator_switcher',
                                                'type'  => 'switcher',
                                                'title' => '禁用wp_generator',
                                                'default'  => false,

                                            ),
                                            array(
                                                'id'    => 'wlwmanifest_switcher',
                                                'type'  => 'switcher',
                                                'title' => '禁用wlwmanifest',
                                                'default'  => false,

                                            ),
                                            array(
                                                'id'    => 'rsd_link_switcher',
                                                'type'  => 'switcher',
                                                'title' => '禁用rsd',
                                                'default'  => false,

                                            ),
                                            array(
                                                'id'    => 'edd_switcher',
                                                'type'  => 'switcher',
                                                'title' => '禁用edd头部',
                                                'default'  => false,

                                            ),
                                            array(
                                                'id'    => 'shortlink_switcher',
                                                'type'  => 'switcher',
                                                'title' => '禁用shortlink',
                                                'default'  => false,

                                            ),
                                            array(
                                                'id'    => 'emoji_switcher',
                                                'type'  => 'switcher',
                                                'title' => '禁用emoji',
                                                'desc'   => 'emoji资源国内不可用，推荐禁用 <a target="_blank" href="https://www.wpxyz.com.cn/wordpress_courese/1.html">了解详情</a>',
                                                'default'  => false,

                                            ),
                                        ];
                                        foreach ($args as $arg){
                                            WPXYZ_switcher($arg);
                                        }
                                        ?>

                                            </tbody>
                                        </table>
                                    </li>
                                    <li>

                                        <table class="uk-table uk-table-striped">
                                            <thead>

                                            <tr>
                                                <th>系统优化</th>
                                            </tr>
                                            </thead>
                                            <tbody>

                                            <?php
                                        $args =[
                                            array(
                                                'id'    => 'trackbacks_switcher',
                                                'type'  => 'switcher',
                                                'title' => '禁用Trackbacks',
                                                'default'  => false,

                                            ),
                                            array(
                                                'id'    => 'XMLRPC_switcher',
                                                'type'  => 'switcher',
                                                'title' => '禁用 XML-RPC 接口',
                                                'default'  => false,

                                            ),
                                            array(
                                                'id'    => 'rest_switcher',
                                                'type'  => 'switcher',
                                                'title' => '屏蔽 REST API',
                                                'default'  => false,

                                            ),
                                            array(
                                                'id'    => 'oEmbed_switcher',
                                                'type'  => 'switcher',
                                                'title' => '屏蔽 Auto OEmbed',
                                                'default'  => false,

                                            ),
                                            array(
                                                'id'    => 'embed_switcher',
                                                'type'  => 'switcher',
                                                'title' => '屏蔽 文章Embed',
                                                'default'  => false,

                                            ),
                                            array(
                                                'id'    => 'gtb_switcher',
                                                'type'  => 'switcher',
                                                'title' => '禁用古腾堡',
                                                'default'  => false,

                                            ),
                                            array(
                                                'id'    => 'no_self_ping_switcher',
                                                'type'  => 'switcher',
                                                'title' => '禁用站内ping',
                                                'default'  => false,

                                            ),
                                        ];
                                        foreach ($args as $arg){
                                            WPXYZ_switcher($arg);
                                        }
                                    ?>
                                        </tbody>
                                        </table>
                                    </li>
                                </ul>
                                </div>
                            </div>


                        </main>
                    </div>
                </div>
            </div>
        </div>
<?php include 'public-active.php'; ?>
<?php include 'public-footer.php'; ?>

