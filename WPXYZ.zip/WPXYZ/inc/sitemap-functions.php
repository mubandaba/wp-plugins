<?php


//sitemap开始
function WPXYZ_sitemap_generate() {
    $myfile = fopen(ABSPATH."sitemap.xml", "w");
    $home_url= get_home_url();

    $time = date('Y-m-d', time());
    $ltime = get_lastpostmodified();
    $ltime = gmdate('Y-m-dTH:i:s+00:00', strtotime($ltime));


    $sitemap = get_option('sitemap_options');

    //首页更新频率
    $changefreq_home    = $sitemap['changefreq_home']     ? $sitemap['changefreq_home'] : 'daily';
    $changefreq_archive = $sitemap['changefreq_archive']  ? $sitemap['changefreq_archive'] : 'daily';
    $changefreq_single = $sitemap['changefreq_single']  ? $sitemap['changefreq_single'] : 'daily';


    // 首页权重
    $priority_home =       $sitemap['priority_home']    ? $sitemap['priority_home']   : '1.0';
    // single权重
    $priority_single =     $sitemap['priority_single']  ? $sitemap['priority_single']    : '0.7';
    // archive权重
    $priority_archive =    $sitemap['priority_archive'] ? $sitemap['priority_archive'] : '0.8';

    // 网站形式 有下面三种选项
    // 'pc'
    //'mobile'
    //'pc,mobile'
    $site_type =           $sitemap['site_type']           ? $sitemap['site_type']       : 'pc,mobile';

    // 要生成的posttype
    $generate_post_types = $sitemap['generate_post_type']  ? $sitemap['generate_post_type'] : '';
    // 要生成的taxonomies
    $generate_taxonomies = $sitemap['generate_taxonomies'];


    $file = <<<EOT
<?xml version="1.0" encoding="UTF-8"?>
<urlset>
 <url> 
     <loc>$home_url</loc>  
      <lastmod>$time</lastmod>
      <changefreq>$changefreq_home</changefreq>
      <priority>$priority_home</priority>
 </url>
EOT;


        $posts_to_show = 10000000000;
        $myposts = get_posts( "numberposts=" . $posts_to_show );
        $urls=[];
        if(is_array($myposts)){
            foreach( $myposts as $post ) {

                $post_id = $post->ID ;
                $post_link = get_permalink($post_id);
                $post_time = get_the_time('Y-m-d',$post_id);

               $file .= "
               <url>
                   <loc>$post_link</loc>
                   <lastmod>$post_time</lastmod>
                   <changefreq>$changefreq_archive</changefreq>
                   <priority>$priority_single</priority>
               </url>\r\n";
            }
        }

        $all_archive_links = get_all_archive_links();
        if(is_array($all_archive_links)){
            foreach ($all_archive_links as $links){
                $file .= "
               <url>
                   <loc>$links</loc>
                   <lastmod>$time</lastmod>
                   <changefreq>$changefreq_archive</changefreq>
                   <priority>$priority_archive</priority>
               </url>\r\n";
            }
        }


//post_type

 //  foreach ($generate_post_types as $generate_post_type){
 //      WPXYZ_generate_sitemap_by_post_type($generate_post_type,$myfile,$changefreq_single,$priority_single,$site_type);
 //  }


 //tax

 //   foreach ($generate_taxonomies as $generate_taxonomy){
 //       WPXYZ_generate_sitemap_by_tax($generate_taxonomy,$myfile,$changefreq_archive,$priority_archive,$site_type);
 //   }
    $file .='</urlset>';

    fwrite($myfile, $file);
    fclose($myfile);
}
add_action( 'wp_ajax_WPXYZ_sitemap_generate', 'WPXYZ_sitemap_generate' );

