<?php
/*
Plugin Name: WordPress 小助手
Plugin URI: https://www.imahui.com/
Description: WordPress 优化加速小助手，加速网站后台速度，后台管理菜单优化及仪表盘等模块移除优化功能。
Version: 1.0.0
Author: 艾码汇
Author URI: https://www.imahui.com/
*/

define('WP_OPTIOMIZE_HELP_PATH', plugin_dir_path(__FILE__));
define('WP_OPTIOMIZE_HELP_URI', plugins_url('', __FILE__));
define('WP_OPTIOMIZE_HELP_FILE',  __FILE__);
include( WP_OPTIOMIZE_HELP_PATH . 'wp-optimize-core.php' );
include( WP_OPTIOMIZE_HELP_PATH . 'wp-optimize-admin.php' );
include( WP_OPTIOMIZE_HELP_PATH . 'wp-optimize-compress.php' );

add_filter( 'plugin_action_links', function( $links, $file ) {
	if ( plugin_basename( __FILE__ ) !== $file ) {
		return $links;
    }
    $settings_link = '<a href="'.add_query_arg( array('page' => 'wp-optimize-help'), admin_url('admin.php') ).'">' . esc_html__( '查看', 'imahui' ) . '</a>';
	array_unshift( $links, $settings_link );
	return $links;
}, 10, 2 );

add_filter( 'plugin_row_meta', function( $links, $file ) {
	if ( plugin_basename( __FILE__ ) !== $file ) {
		return $links;
	}
	$document_link = sprintf( '<a href="%s" target="%s" aria-label="%s" data-title="%s">%s</a>',
		esc_url( 'https://www.weitimes.com/' ),
		esc_attr( "_blank" ),
		esc_attr( '更多关于 丸子小程序 的信息' ),
		esc_attr( '丸子小程序' ),
		esc_html( '丸子小程序' )
	);
	$miniprogram_link = sprintf( '<a href="%s" target="%s" aria-label="%s" data-title="%s">%s</a>',
		esc_url( 'https://www.wpstorm.cn/' ),
		esc_attr( "_blank" ),
		esc_attr( '更多关于 丸子小程序 的信息' ),
		esc_attr( 'WordPress 小程序' ),
		esc_html( 'WordPress 小程序' )
	);
	$more_link = array( 'document' => $document_link, 'miniprogram' => $miniprogram_link );
	$links = array_merge( $links, $more_link );
	return $links;
}, 10, 2 );

add_action( 'admin_init', function() {
	register_setting( "wp_optimize_option-group", "wp_optimize_option" );
});

add_action( 'admin_menu', function() {
	global $menu, $submenu;
	$restricted = array();
	$options = get_option('wp_optimize_option');
	add_menu_page( 'WordPress 优化小助手', '优化加速', 'manage_options', 'wp-optimize-help', 'wp_optimize_admin_option', 'dashicons-lightbulb', 80 );
	if( isset($options['posts']) && $options['posts'] ) { $restricted[]=__('Posts'); }
	if( isset($options['media']) && $options['media'] ) { $restricted[]=__('Media'); }
	if( isset($options['pages']) && $options['pages'] ) { $restricted[]=__('Pages'); }
	if( isset($options['theme']) && $options['theme'] ) { $restricted[]=__('Appearance'); }
	if( isset($options['tools']) && $options['tools'] ) { $restricted[]=__('Tools'); }
	if( isset($options['users']) && $options['users'] ) { $restricted[]=__('Users'); }
	if( isset($options['comments']) && $options['comments'] ) { $restricted[]=__('Comments'); }
	if( isset($options['plugins']) && $options['plugins'] ) { $restricted[]=__('Plugins'); }
	$restricted;
	end ($menu);
	while (prev($menu)) {
		$value = explode(' ',$menu[key($menu)][0]);
		if(strpos($value[0], '<') === FALSE) {
			if(in_array($value[0] != NULL ? $value[0]:"" , $restricted)){
				unset($menu[key($menu)]);
			}
		}else {
			$value2 = explode('<', $value[0]);
			if(in_array($value2[0] != NULL ? $value2[0]:"" , $restricted)){
				unset($menu[key($menu)]);
			}
		}
	}
	if( isset($options['privacy']) && $options['privacy'] ) {
		unset($submenu['options-general.php'][45]);
		remove_action( 'admin_menu', '_wp_privacy_hook_requests_page' );
		remove_filter( 'wp_privacy_personal_data_erasure_page', 'wp_privacy_process_personal_data_erasure_page', 10, 5 );
		remove_filter( 'wp_privacy_personal_data_export_page', 'wp_privacy_process_personal_data_export_page', 10, 7 );
		remove_filter( 'wp_privacy_personal_data_export_file', 'wp_privacy_generate_personal_data_export_file', 10 );
		remove_filter( 'wp_privacy_personal_data_erased', '_wp_privacy_send_erasure_fulfillment_notification', 10 );
		remove_action( 'admin_init', array( 'WP_Privacy_Policy_Content', 'text_change_check' ), 100 );
		remove_action( 'edit_form_after_title', array( 'WP_Privacy_Policy_Content', 'notice' ) );
		remove_action( 'admin_init', array( 'WP_Privacy_Policy_Content', 'add_suggested_content' ), 1 );
		remove_action( 'post_updated', array( 'WP_Privacy_Policy_Content', '_policy_page_updated' ) );
	}
}, 11 );

function get_optimize_option( $option ) {
	$options = get_option('wp_optimize_option');
	if( isset($options[$option]) ) {
		return $options[$option];
	}
	return '';
}

add_filter('admin_footer_text', function ( $text ) {
    $text = '<span id="footer-thankyou">感谢使用 <a href=http://cn.wordpress.org/ target="_blank">WordPress</a>进行创作，<a target="_blank" rel="nofollow" href="https://www.weitimes.com/">点击访问</a> WordPress 小程序专业版。</span>';
    return $text;
});

function wp_useAgent_Browser( ) {
	$userAgent = $_SERVER['HTTP_USER_AGENT'];
	$browser   = "unkown";
	if( preg_match('/Chrome\/[\d\.\w]*/', $userAgent, $match) ) {
		$browser = "chrome";
	} else if( preg_match('/Safari\/[\d\.\w]*/', $userAgent, $match) ) {
		$browser = "safari";
	} else if( preg_match('/Mozilla\/5.0 [\d\.\w]*/', $userAgent, $match) ) {
		$browser = "ie";
	} else if( preg_match('/Edge\/[\d\.\w]*/', $userAgent, $match) ) {
		$browser = "edge";
	} else if( preg_match('/Opera\/[\d\.\w]*/', $userAgent, $match) ) {
		$browser = "opera";
	} else if( preg_match('/Firefox\/[\d\.\w]*/', $userAgent, $match) ) {
		$browser = "firefox";
	} else if( preg_match('/OmniWeb\/(v*)([^\s|;]+)/i', $userAgent, $match) ) {
		$browser = "omniweb";
	} else if( preg_match('/Netscape([\d]*)\/([^\s]+)/i', $userAgent, $match) ) {
		$browser = "netscape";
	} else if( preg_match('/Lynx\/([^\s]+)/i', $userAgent, $match) ) {
		$browser = "lynx";
	} else if( preg_match('/360SE/i', $userAgent, $match) ) {
		$browser = "360se";
	} else if( preg_match('/SE 2.x/i', $userAgent, $match) ) {
		$browser = "sogou";
	}
	return $browser;
}