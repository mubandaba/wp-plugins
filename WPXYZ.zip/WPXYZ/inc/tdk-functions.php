<?php
// 防止本文件直接被访问
// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

// TDK 默认值
function TDK_default(){

    $front_page_TDK = get_option('front_page_TDK');
    $archive_page_TDK = get_option('archive_page_TDK');
    $single_page_TDK = get_option('single_page_TDK');


    if(is_array($front_page_TDK)){

        if(!$front_page_TDK['title']){
            $front_page_TDK['title'] ='{{site_name}}_{{site_description}}';
        }
        if(!$front_page_TDK['keywords']){
            $front_page_TDK['keywords'] ='{{site_name}}';
        }
        if(!$front_page_TDK['description']){
            $front_page_TDK['description'] ='{{site_description}}';
        }
    }

    if(is_array($archive_page_TDK)){

        if(!$archive_page_TDK['title']){
            $archive_page_TDK['title'] ='{{single_title}}_{{site_name}}';
        }
        if(!$archive_page_TDK['keywords']){
            $archive_page_TDK['keywords'] ='{{single_title}},{{single_categories}},{{site_name}}';
        }
        if(!$archive_page_TDK['description']){
            $archive_page_TDK['description'] ='{{single_title}},{{single_categories}},{{site_name}},{{site_description}}';
        }
        
    }

    if(is_array($single_page_TDK)){

        if(!$single_page_TDK['title']){
            $single_page_TDK['title'] ='{{single_title}}_{{site_name}}';
        }
        if(!$single_page_TDK['keywords']){
            $single_page_TDK['keywords'] ='{{single_title}},{{site_name}}';
        }
        if(!$single_page_TDK['description']){
            $single_page_TDK['description'] ='{{single_title}},{{site_name}},{{site_description}}';
        }
    }

    update_option('front_page_TDK',$front_page_TDK  );
    update_option('archive_page_TDK',$archive_page_TDK);
    update_option('single_page_TDK',$single_page_TDK );
}


// 全局变量替换
function global_replace($input){
    $site_title = get_bloginfo('name');
    $site_description = get_bloginfo('description');
    $input = str_replace('{{site_name}}',$site_title,$input);
    $input = str_replace("{{site_description}}",$site_description,$input);
    return $input;
}
// single页变量替换
function single_replace($input){
    $title = get_the_title();

    $categories = '';
    $i = 1;
    foreach((get_the_category()) as $category){
        if($i > 1){
            $categories.= ',';
        }
        $categories.=  $category->cat_name;
        $i++;
    }

    $input = str_replace('{{single_title}}',$title,$input);
    $input = str_replace('{{single_categories}}',$categories,$input);

    return $input;
}

// archive页变量替换
function archive_replace($input){
    $title = single_cat_title( '', false ) ;
    $description = wp_strip_all_tags(category_description());

    $input = str_replace('{{archive_title}}',$title,$input);
    $input = str_replace('{{archive_description}}',$description,$input);
    return $input;
}

add_theme_support( 'title-tag' );

function xyz_title(){

    if( (is_home() || is_front_page()) ) {
        $front_page_TDK = get_option('front_page_TDK');
        $title = $front_page_TDK['title'];
        if($title){
            $title =  global_replace($title);
            return $title;
        }
    }
    elseif (is_single()||is_page()) {
        $id = get_the_ID();
        $title = get_post_meta($id,'title',true);
        if(!$title){
            $single_page_TDK = get_option('single_page_TDK');
            $title = $single_page_TDK['title'];
            $title =  global_replace($title);
            $title =  single_replace($title);
            return $title;
        }
    }
    elseif (is_archive()) {
        $archive_object = get_queried_object();
        $title = get_term_meta( $archive_object->term_id, 'title', true );

        if(!$title){

            $archive_page_TDK = get_option('archive_page_TDK');
            $title = $archive_page_TDK['title'];

            $title =  global_replace($title);
            $title =  archive_replace($title);

            return $title;
        }

    }

}
add_filter( 'pre_get_document_title', 'xyz_title' );

function xyz_keywords(){

    if( (is_home() || is_front_page()) ) {
        $front_page_TDK = get_option('front_page_TDK');
        $keywords = $front_page_TDK['keywords'];
    }
    elseif (is_single()||is_page()) {
        $id = get_the_ID();
        $keywords = get_post_meta($id,'keywords',true);
        $keywords =  single_replace($keywords);
    }
    elseif (is_archive()) {
        $archive_object = get_queried_object();
        $keywords = get_term_meta( $archive_object->term_id, 'archive_title', true );
        $keywords =  archive_replace($keywords);
    }
    $keywords =  global_replace($keywords);
    echo "<meta name=\"keywords\" content=\"$keywords\" />";

}
function xyz_description(){

    if( (is_home() || is_front_page()) ) {
        $front_page_TDK = get_option('front_page_TDK');
        $description = $front_page_TDK['description'];
     }
    elseif (is_single()||is_page()) {
        $id = get_the_ID();
        $description = get_post_meta($id,'description',true);
        $description =  single_replace($description);
    }
    elseif (is_archive()) {
        $archive_object = get_queried_object();
        $description = get_term_meta( $archive_object->term_id, 'description', true );
        $description =  archive_replace($description);

    }

    $description =  global_replace($description);
    echo "<meta name=\"description\" content=\"$description\"/>";

}

add_action('wp_head','xyz_keywords',1);
add_action('wp_head','xyz_description',1);
