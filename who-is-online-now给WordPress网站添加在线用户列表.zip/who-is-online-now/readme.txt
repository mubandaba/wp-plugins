=== Who Is Online Now ===
Contributors: wpmonkeys
Tags: online live visitor, live visitor count, online visitor, ajax online visitor
Stable tag: trunk
Requires at least: 3.0.1
Tested up to: 5.3
Stable tag: trunk
Requires PHP: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

See how many Visitor and Author's are online also how many from mobile device by this plugin. Its a Ajax based plugin. Its will also show member avatar or member display name who is online right now.

== Description ==

Who is online Now is an Awesome plugin to show who is online right now in your website. Its a ajax based plugin so no need to refresh the page it will auto refresh itsself after your set time period. 

**Features:**

-   Super Easy to use, Search Install Active And you Done!
-   Shortcode Powered
-   Use [who-is-online-now] to show online visitor anywhere in your website.
-   Super Setting Panel.
-   Ajax Based.
-   Very Lightweight
-   You Can set auto refresh time period from setting panel.
-   You Show/Hide Author Name/Profile Image
-   You Can change Author Image Size from setting panel
-   You Can change Text Strings from Setting Panel.
-   Responsive Design
-   Developer Friendly
-   Works with any standards compliant WordPress theme
-   Plays well with other Plugins
-   100% Customizable


### Shortcodes to use Who is online Now
`
[who-is-online-now]
`

### Note:
We have fully confidence that our plugin working very well for any theme. But in case you face any problem with our plugin or any customization needed please Contact in our [Support Forum](https://wpmonkeys.com/support/)
our support team will back to you shortly.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress


== Frequently Asked Questions ==

= is Who is Online is free =

Yes its a Free version.

= How i show online visitor =

Use [who-is-online-now] to show online visitor anywhere in your website.

= Plugin Is not working in my site! Need Help =

We have fully confidence that our plugin working very well for any theme. But in case you face any problem with our plugin or any customization needed please Contact in our [Support Forum](http://support.wpmonkeys.com/)
our support team will back to you shortly.





== Changelog ==

= 1.0 =
* Initial Release


= 1.0.1 =
* Fixed Duplicate data in WordPress Database error issue.