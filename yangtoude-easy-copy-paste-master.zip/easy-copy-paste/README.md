# easy-copy-paste
让你的复制粘贴更加容易。文章发布或更新时，抓取文章中外站的图片上传到媒体库并替换图片的src。

- Contributors:       yangtoude
- Tags:               wordpress, copy, paste
- Requires at least:  4.5
- Tested up to:       4.5
- Stable tag:         trunk
- License:            GPLv2 or later
- License URI:        http://www.gnu.org/licenses/gpl-2.0.html

## Description
文章发布或更新时，抓取文章中外站的图片上传到媒体库并替换图片的src。

## Installation

1. 上传 `wp-bos`目录 到 `/wp-content/plugins/` 目录
2. 在后台插件菜单激活该插件
3. 在Easy Copy Paste设置页面填写好配置
开始使用吧！

## Changelog

### 1.0.0
* 初始版本
