<?php

add_filter('print_scripts_array', function($to_do) {
	$browser	= wp_useAgent_Browser();
	$wp_scripts	= wp_scripts();
	$in_header	= in_array('do_head_items', wp_list_pluck(debug_backtrace(), 'function'));

	foreach($to_do as $handle){
		if($in_header && $wp_scripts->groups[$handle]) {
			continue;
		}

		if($wp_scripts->registered[$handle]->textdomain) {
			$translations	= $wp_scripts->print_translations( $handle, false );

			if($translations){
				$translations	= sprintf("<script type='text/javascript' id='%s-js-translations'>\n%s\n</script>\n", esc_attr($handle), $translations);

				$wp_scripts->print_html .= $translations;
			}

			$wp_scripts->registered[$handle]->textdomain	= '';
		}

		if(in_array($browser, ['safari', 'chrome', 'edge', 'firefox', 'opera'])) {
			if(in_array($handle, ['wp-polyfill','lodash','editor'])) {
				unset($wp_scripts->registered[$handle]->extra['after']);
			}
		}

		if($after = $wp_scripts->print_inline_script($handle, 'after', false)) {
			$wp_scripts->print_html .= "<script type='text/javascript'>\n".$after."\n</script>\n";
			unset($wp_scripts->registered[$handle]->extra['after']);
		}

		if($before = $wp_scripts->print_inline_script($handle, 'before', false)) {
			$wp_scripts->print_code .= $before."\n";
			unset($wp_scripts->registered[$handle]->extra['before']);
			$wp_scripts->add_data($handle, 'data', "\n".$before."\n");

		}

	}

	return array_diff($to_do, ['json2']);
});

add_action('wp_default_styles', function( $styles ) {
	$default_dirs = [
		'/wp-includes/js/thickbox/', 
		'/wp-includes/js/mediaelement/', 
		'/wp-includes/js/imgareaselect/'
	];
	$styles->default_dirs = array_merge($styles->default_dirs, $default_dirs);
});