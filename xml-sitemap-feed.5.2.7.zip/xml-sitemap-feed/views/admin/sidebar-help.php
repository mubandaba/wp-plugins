<h3><span class="dashicons dashicons-sos"></span> <?php echo translate('Help'); ?></h3>
<p>
	<?php printf (
	/* translators: Support forum URL on WordPress.org */
	__( 'You can find instructions on the help tab above. If you still have questions, please go to the <a href="%s" target="_blank">Support forum</a>.', 'xml-sitemap-feed' ),
	'https://wordpress.org/support/plugin/xml-sitemap-feed'
	); ?>
</p>
