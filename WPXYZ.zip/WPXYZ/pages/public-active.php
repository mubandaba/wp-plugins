
<?php if(!WPXYZ_is_actived()):?>
    <div id="activation" uk-modal>
        <div class="uk-modal-dialog uk-modal-body uk-margin-large-top">
            <h2 class="uk-text-center uk-h2">激活小宇宙插件</h2>

            <p class="uk-text-meta uk-text-center">微信扫码关注公众号，并发送“小宇宙”获取激活码</p>
            <p class="uk-text-center">
                <img src="<?php echo $site_url;?>/wp-content/plugins/WPXYZ/static/img/qrcode.jpg" style="height: 160px;width: 160px">
            </p>
            <p class="uk-text-center">
                <input id="license_input" class="uk-input uk-form-width-medium uk-form-small" type="text" placeholder="输入激活码">
            </p>
            <p class="uk-text-center">
                <button id="license_submit" type="submit" class="button button-primary" style="background: #0f33ffd4!important;color: #ffffff!important;box-shadow: none;border-radius: 50px;text-shadow: none;" >立即激活</button>
            </p>
        </div>
    </div>

    <script>
        window.onload=function (){
            UIkit.modal('#activation').show();
        };
    </script>

<?php endif;?>

