<?php

if ( ! defined('ABSPATH') ) 
	die();

?>
<script type="text/html" id="tmpl-thepaste-grabber">
	<div class="media-frame-title">
		<h1>{{{ data.title }}}</h1>
	</div>
	<div class="content">
	</div>
</script>
