<?php

if ( ! defined('ABSPATH') )
	die();

?>
<script type="text/html" id="tmpl-thepaste-pasteboard">
	<div class="injector" contenteditable tabindex="0"></div>
	<div class="instructions"><?php _e('Paste some image Data from your clipboard','the-paste'); ?></div>
	<div class="message"></div>
	<div class="click-here"><div><?php _e( 'Click here please...' ); ?></div><div>
</script>
