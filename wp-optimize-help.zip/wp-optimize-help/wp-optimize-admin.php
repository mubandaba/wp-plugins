<?php

if ( !defined( 'ABSPATH' ) ) exit;

function wp_optimize_admin_option( ) {
	$options = get_option('wp_optimize_option');
?>
    <div class="wrap">
        <h2 class="nav-tab-wrapper nav-tab-title wp-clearfix">
        <a id="tab-optimize" href="javascript:;" class="nav-tab" data-id="optimize">加速优化</a>
        <a id="tab-menu" href="javascript:;" class="nav-tab" data-id="menu">优化菜单</a>
        <a id="tab-dashboard" href="javascript:;" class="nav-tab" data-id="dashboard">仪表盘</a>
        <a id="tab-widget" href="javascript:;" class="nav-tab" data-id="widget">小工具</a>
        </h2>
        <hr class="wp-header-end">
        <div class="optimize-manage-wrap">
        <form id="optimize-options" method="post" action="options.php" enctype="multipart/form-data">
            <?php settings_fields( 'wp_optimize_option-group' ); ?>
            <?php do_settings_sections( 'wp_optimize_option-group' ); ?>
            <div id="optimize-options" class="optimize-option">
            <h3>网站加速优化设置</h3>
            <table class="form-table" cellspacing="0">
            <tbody>
            <tr id="open_sans">
			<th><label for="open_sans">禁用谷歌字体</label></th>
			<td><input type="checkbox" id="open_sans" name="wp_optimize_option[open_sans]" <?php $open_sans = isset($options['open_sans']) ? $options['open_sans'] : 0; checked( boolval( $open_sans ), true, true ); ?> value="1"><span class="description">是否禁用谷歌开源字体, 使用微软雅黑/苹果方正字体(建议禁用)</span></td>
            </tr>
            <tr id="admin_bar">
			<th><label for="admin_bar">禁用工具栏</label></th>
			<td><input type="checkbox" id="admin_bar" name="wp_optimize_option[admin_bar]" <?php $admin_bar = isset($options['admin_bar']) ? $options['admin_bar'] : 0; checked( boolval( $admin_bar ), true, true ); ?> value="1"><span class="description">是否禁用顶部管理工具栏, 仅限前端用户</span></td>
            </tr>
            <tr id="generator">
		    <th><label for="generator">移除版本号</label></th>
			<td><input type="checkbox" id="generator" name="wp_optimize_option[generator]" <?php $generator = isset($options['generator']) ? $options['generator'] : 0; checked( boolval( $generator ), true, true ); ?> value="1"><span class="description">是否移除头部 WordPress 版本号信息</span></td>
            </tr>
            <tr id="o_link">
			<th><label for="o_link">移除离线接口</label></th>
			<td><input type="checkbox" id="o_link" name="wp_optimize_option[o_link]" <?php $o_link = isset($options['o_link']) ? $options['o_link'] : 0; checked( boolval( $o_link ), true, true ); ?> value="1"><span class="description">是否禁用离线发布接口, 如果不使用第三方 App 或者软件发布文章, 建议禁用</span></td>
            </tr>
            <tr id="feed">
			<th><label for="feed">禁用 Feed 功能</label></th>
			<td><input type="checkbox" id="feed" name="wp_optimize_option[feed]" <?php $feed = isset($options['feed']) ? $options['feed'] : 0; checked( boolval( $feed ), true, true ); ?> value="1"><span class="description">是否禁用 Feed 功能, 如果不提供给第三方订阅, 建议禁用, 有助于反爬虫</span></td>
            </tr>
            <tr id="emoji">
			<th><label for="emoji">移除 Emoji 表情</label></th>
			<td><input type="checkbox" id="emoji" name="wp_optimize_option[emoji]" <?php $emoji = isset($options['emoji']) ? $options['emoji'] : 0; checked( boolval( $emoji ), true, true ); ?> value="1"><span class="description">是否移除评论 Emoji 表情</span></td>
            </tr>
            <tr id="gravatar">
			<th><label for="gravatar">Gravatar 镜像</label></th>
			<td><input type="checkbox" id="gravatar" name="wp_optimize_option[gravatar]" <?php $gravatar = isset($options['gravatar']) ? $options['gravatar'] : 0; checked( boolval( $gravatar ), true, true ); ?> value="1"><span class="description">是否使用国内的 Gravatar 镜像服务，提高网站加载速度</span></td>
            </tr>
            <tr id="oembed">
			<th><label for="oembed">禁止 Head 加载</label></th>
			<td><input type="checkbox" id="oembed" name="wp_optimize_option[oembed]" <?php $oembed = isset($options['oembed']) ? $options['oembed'] : 0; checked( boolval( $oembed ), true, true ); ?> value="1"><span class="description">是否禁止 Head 加载 Embeds、s.w.org 和 api.w.org</span></td>
            </tr>
            <tr id="srcset">
			<th><label for="srcset">禁止响应式图片</label></th>
			<td><input type="checkbox" id="srcset" name="wp_optimize_option[srcset]" <?php $srcset = isset($options['srcset']) ? $options['srcset'] : 0; checked( boolval( $srcset ), true, true ); ?> value="1"><span class="description">是否禁止 IMG 标签加载响应式图片自动裁剪</span></td>
            </tr>
            <tr id="spam">
			<th><label for="spam">禁止垃圾评论</label></th>
			<td><input type="checkbox" id="spam" name="wp_optimize_option[spam]" <?php $spam = isset($options['spam']) ? $options['spam'] : 0; checked( boolval( $spam ), true, true ); ?> value="1"><span class="description">是否禁止纯英文或日文评论发布(建议禁止，过滤垃圾评论)</span></td>
            </tr>
            <tr id="update_core">
			<th><label for="update_core">关闭核心更新</label></th>
			<td><input type="checkbox" id="plugins" name="wp_optimize_option[update_core]" <?php $update_core = isset($options['update_core']) ? $options['update_core'] : 0; checked( boolval( $update_core ), true, true ); ?> value="1"><span class="description">是否关闭 WordPress 核心更新提示(注意：关闭更新需要手动进行)</span></td>
            </tr>
            <tr id="update_plugins">
			<th><label for="update_plugins">关闭插件更新</label></th>
			<td><input type="checkbox" id="update_plugins" name="wp_optimize_option[update_plugins]" <?php $update_plugins = isset($options['update_plugins']) ? $options['update_plugins'] : 0; checked( boolval( $update_plugins ), true, true ); ?> value="1"><span class="description">是否关闭 WordPress 插件更新提示(注意：关闭更新需要手动进行)</span></td>
            </tr>
            <tr id="update_themes">
			<th><label for="update_themes">关闭主题更新</label></th>
			<td><input type="checkbox" id="update_themes" name="wp_optimize_option[update_themes]" <?php $update_themes = isset($options['update_themes']) ? $options['update_themes'] : 0; checked( boolval( $update_themes ), true, true ); ?> value="1"><span class="description">是否关闭 WordPress 主题更新提示(注意：关闭更新需要手动进行)</span></td>
            </tr>
            <tr id="trackbacks">
			<th><label for="trackbacks">关闭 Trackbacks</label></th>
			<td><input type="checkbox" id="trackbacks" name="wp_optimize_option[trackbacks]" <?php $trackbacks = isset($options['trackbacks']) ? $options['trackbacks'] : 0; checked( boolval( $trackbacks ), true, true ); ?> value="1"><span class="description">是否关闭 Pingbacks 和 Trackbacks 引用信息</span></td>
            </tr>
            <tr id="xml_rpc">
			<th><label for="xml_rpc">关闭 XML-RPC 服务</label></th>
			<td><input type="checkbox" id="xml_rpc" name="wp_optimize_option[xml_rpc]" <?php $xml_rpc = isset($options['xml_rpc']) ? $options['xml_rpc'] : 0; checked( boolval( $xml_rpc ), true, true ); ?> value="1"><span class="description">是否关闭 XML-RPC 服务功能, 如果不需要使用 WordPress App 发表文章, 建议关闭</span></td>
            </tr>
            </tbody>
            </table>
            </div>
            <div id="menu-options" class="optimize-option">
            <h3>管理菜单隐藏设置</h3>
            <table class="form-table" cellspacing="0">
            <tbody>
            <tr id="posts">
			<th><label for="posts">移除文章</label></th>
			<td><input type="checkbox" id="posts" name="wp_optimize_option[posts]" <?php $posts = isset($options['posts']) ? $options['posts'] : 0; checked( boolval( $posts ), true, true ); ?> value="1"><span class="description">是否屏蔽左侧文章菜单</span></td>
            </tr>
            <tr id="media">
		    <th><label for="media">移除媒体</label></th>
			<td><input type="checkbox" id="media" name="wp_optimize_option[media]" <?php $media = isset($options['media']) ? $options['media'] : 0; checked( boolval( $media ), true, true ); ?> value="1"><span class="description">是否屏蔽左侧媒体菜单</span></td>
            </tr>
            <tr id="pages">
			<th><label for="pages">移除页面</label></th>
			<td><input type="checkbox" id="pages" name="wp_optimize_option[pages]" <?php $pages = isset($options['pages']) ? $options['pages'] : 0; checked( boolval( $pages ), true, true ); ?> value="1"><span class="description">是否屏蔽左侧页面菜单</span></td>
            </tr>
            <tr id="theme">
			<th><label for="theme">移除外观</label></th>
			<td><input type="checkbox" id="theme" name="wp_optimize_option[theme]" <?php $theme = isset($options['theme']) ? $options['theme'] : 0; checked( boolval( $theme ), true, true ); ?> value="1"><span class="description">是否屏蔽左侧外观菜单</span></td>
            </tr>
            <tr id="tools">
			<th><label for="tools">移除工具</label></th>
			<td><input type="checkbox" id="tools" name="wp_optimize_option[tools]" <?php $tools = isset($options['tools']) ? $options['tools'] : 0; checked( boolval( $tools ), true, true ); ?> value="1"><span class="description">是否屏蔽左侧工具菜单</span></td>
            </tr>
            <tr id="users">
			<th><label for="users">移除用户</label></th>
			<td><input type="checkbox" id="users" name="wp_optimize_option[users]" <?php $users = isset($options['users']) ? $options['users'] : 0; checked( boolval( $users ), true, true ); ?> value="1"><span class="description">是否屏蔽左侧用户菜单</span></td>
            </tr>
            <tr id="comments">
			<th><label for="comments">移除评论</label></th>
			<td><input type="checkbox" id="comments" name="wp_optimize_option[comments]" <?php $comments = isset($options['comments']) ? $options['comments'] : 0; checked( boolval( $comments ), true, true ); ?> value="1"><span class="description">是否屏蔽左侧评论菜单</span></td>
            </tr>
            <tr id="plugins">
			<th><label for="plugins">移除插件</label></th>
			<td><input type="checkbox" id="plugins" name="wp_optimize_option[plugins]" <?php $plugins = isset($options['plugins']) ? $options['plugins'] : 0; checked( boolval( $plugins ), true, true ); ?> value="1"><span class="description">是否屏蔽左侧插件菜单</span></td>
            </tr>
            <tr id="privacy">
			<th><label for="privacy">移除隐私</label></th>
			<td><input type="checkbox" id="privacy" name="wp_optimize_option[privacy]" <?php $privacy = isset($options['privacy']) ? $options['privacy'] : 0; checked( boolval( $privacy ), true, true ); ?> value="1"><span class="description">是否屏蔽左侧隐私页面</span></td>
            </tr>
            </tbody>
            </table>
            </div>
            <div id="dashboard-options" class="optimize-option">
            <h3>仪表盘小工具模块屏蔽设置</h3>
            <table class="form-table" cellspacing="0">
            <tbody>
            <tr id="wplogo">
			<th><label for="wplogo">WordPress Logo</label></th>
			<td><input type="checkbox" id="wplogo" name="wp_optimize_option[wplogo]" <?php $wplogo = isset($options['wplogo']) ? $options['wplogo'] : 0; checked( boolval( $wplogo ), true, true ); ?> value="1"><span class="description">是否移除左上角 WordPress Logo 及链接</span></td>
            </tr>
            <tr id="help">
			<th><label for="help">显示选项与帮助</label></th>
			<td><input type="checkbox" id="help" name="wp_optimize_option[help]" <?php $help = isset($options['help']) ? $options['help'] : 0; checked( boolval( $help ), true, true ); ?> value="1"><span class="description">是否移除右上角显示选项 / 帮助</span></td>
            </tr>
            <tr id="welcome_panel">
			<th><label for="welcome_panel">欢迎信息</label></th>
			<td><input type="checkbox" id="welcome_panel" name="wp_optimize_option[welcome_panel]" <?php $welcome_panel = isset($options['welcome_panel']) ? $options['welcome_panel'] : 0; checked( boolval( $welcome_panel ), true, true ); ?> value="1"><span class="description">是否移除仪表盘欢迎信息</span></td>
            </tr>
            <tr id="widget_rss">
			<th><label for="now">首页概况</label></th>
			<td><input type="checkbox" id="now" name="wp_optimize_option[now]" <?php $now = isset($options['now']) ? $options['now'] : 0; checked( boolval( $now ), true, true ); ?> value="1"><span class="description">是否移除仪表盘首页概况</span></td>
            </tr>
            <tr id="activity">
			<th><label for="activity">首页活动</label></th>
			<td><input type="checkbox" id="activity" name="wp_optimize_option[activity]" <?php $activity = isset($options['activity']) ? $options['activity'] : 0; checked( boolval( $activity ), true, true ); ?> value="1"><span class="description">是否移除仪表盘首页活动</span></td>
            </tr>
            <tr id="quick">
		    <th><label for="quick">快速发布</label></th>
			<td><input type="checkbox" id="quick" name="wp_optimize_option[quick]" <?php $quick = isset($options['quick']) ? $options['quick'] : 0; checked( boolval( $quick ), true, true ); ?> value="1"><span class="description">是否移除仪表盘首页快速发布</span></td>
            </tr>
            <tr id="income">
			<th><label for="income">引入链接</label></th>
			<td><input type="checkbox" id="income" name="wp_optimize_option[income]" <?php $income = isset($options['income']) ? $options['income'] : 0; checked( boolval( $income ), true, true ); ?> value="1"><span class="description">是否移除仪表盘首页引入链接</span></td>
            </tr>
            <tr id="site_health">
			<th><label for="site_health">站点健康</label></th>
			<td><input type="checkbox" id="site_health" name="wp_optimize_option[site_health]" <?php $site_health = isset($options['site_health']) ? $options['site_health'] : 0; checked( boolval( $site_health ), true, true ); ?> value="1"><span class="description">是否移除仪表盘首页站点健康状态</span></td>
            </tr>
            <tr id="recent">
			<th><label for="recent">最近评论</label></th>
			<td><input type="checkbox" id="recent" name="wp_optimize_option[recent]" <?php $recent = isset($options['recent']) ? $options['recent'] : 0; checked( boolval( $recent ), true, true ); ?> value="1"><span class="description">是否移除仪表盘首页最近评论</span></td>
            </tr>
            <tr id="drafts">
			<th><label for="drafts">最近草稿</label></th>
			<td><input type="checkbox" id="drafts" name="wp_optimize_option[drafts]" <?php $drafts = isset($options['drafts']) ? $options['drafts'] : 0; checked( boolval( $drafts ), true, true ); ?> value="1"><span class="description">是否移除仪表盘首页最近草稿</span></td>
            </tr>
            <tr id="primary">
			<th><label for="primary">开发日志</label></th>
			<td><input type="checkbox" id="primary" name="wp_optimize_option[primary]" <?php $primary = isset($options['primary']) ? $options['primary'] : 0; checked( boolval( $primary ), true, true ); ?> value="1"><span class="description">是否移除仪表盘首页开发日志</span></td>
            </tr>
            <tr id="secondary">
			<th><label for="secondary">活动新闻</label></th>
			<td><input type="checkbox" id="secondary" name="wp_optimize_option[secondary]" <?php $secondary = isset($options['secondary']) ? $options['secondary'] : 0; checked( boolval( $secondary ), true, true ); ?> value="1"><span class="description">是否移除仪表盘首页 WordPress 活动及新闻</span></td>
            </tr>
            </tbody>
            </table>
            </div>
            <div id="widget-options" class="optimize-option">
            <h3>默认小工具清理移除设置</h3>
            <table class="form-table" cellspacing="0">
            <tbody>
            <tr id="widget_rss">
			<th><label for="widget_rss">移除 RSS</label></th>
			<td><input type="checkbox" id="widget_rss" name="wp_optimize_option[widget_rss]" <?php $widget_rss = isset($options['widget_rss']) ? $options['widget_rss'] : 0; checked( boolval( $widget_rss ), true, true ); ?> value="1"><span class="description">是否移除小工具 RSS 模块</span></td>
            </tr>
            <tr id="widget_categories">
			<th><label for="widget_categories">移除分类目录</label></th>
			<td><input type="checkbox" id="widget_categories" name="wp_optimize_option[widget_categories]" <?php $widget_categories = isset($options['widget_categories']) ? $options['widget_categories'] : 0; checked( boolval( $widget_categories ), true, true ); ?> value="1"><span class="description">是否移除小工具分类目录模块</span></td>
            </tr>
            <tr id="widget_meta">
		    <th><label for="widget_meta">移除功能</label></th>
			<td><input type="checkbox" id="widget_meta" name="wp_optimize_option[widget_meta]" <?php $widget_meta = isset($options['widget_meta']) ? $options['widget_meta'] : 0; checked( boolval( $widget_meta ), true, true ); ?> value="1"><span class="description">是否移除小工具功能模块</span></td>
            </tr>
            <tr id="widget_media_image">
			<th><label for="widget_media_image">移除图像</label></th>
			<td><input type="checkbox" id="widget_media_image" name="wp_optimize_option[widget_media_image]" <?php $widget_media_image = isset($options['widget_media_image']) ? $options['widget_media_image'] : 0; checked( boolval( $widget_media_image ), true, true ); ?> value="1"><span class="description">是否移除小工具图像模块</span></td>
            </tr>
            <tr id="widget_nav_menu">
			<th><label for="widget_nav_menu">移除导航菜单</label></th>
			<td><input type="checkbox" id="widget_nav_menu" name="wp_optimize_option[widget_nav_menu]" <?php $widget_nav_menu = isset($options['widget_nav_menu']) ? $options['widget_nav_menu'] : 0; checked( boolval( $widget_nav_menu ), true, true ); ?> value="1"><span class="description">是否移除小工具导航菜单模块</span></td>
            </tr>
            <tr id="widget_search">
			<th><label for="widget_search">移除搜索</label></th>
			<td><input type="checkbox" id="widget_search" name="wp_optimize_option[widget_search]" <?php $widget_search = isset($options['widget_search']) ? $options['widget_search'] : 0; checked( boolval( $widget_search ), true, true ); ?> value="1"><span class="description">是否移除小工具搜索模块</span></td>
            </tr>
            <tr id="widget_text">
			<th><label for="widget_text">移除文本</label></th>
			<td><input type="checkbox" id="widget_text" name="wp_optimize_option[widget_text]" <?php $widget_text = isset($options['widget_text']) ? $options['widget_text'] : 0; checked( boolval( $widget_text ), true, true ); ?> value="1"><span class="description">是否移除小工具文本模块</span></td>
            </tr>
            <tr id="widget_archives">
			<th><label for="widget_archives">移除文章归档</label></th>
			<td><input type="checkbox" id="widget_archives" name="wp_optimize_option[widget_archives]" <?php $widget_archives = isset($options['widget_archives']) ? $options['widget_archives'] : 0; checked( boolval( $widget_archives ), true, true ); ?> value="1"><span class="description">是否移除小工具文章归档模块</span></td>
            </tr>
            <tr id="widget_calendar">
			<th><label for="widget_calendar">移除日历</label></th>
			<td><input type="checkbox" id="widget_calendar" name="wp_optimize_option[widget_calendar]" <?php $widget_calendar = isset($options['widget_calendar']) ? $options['widget_calendar'] : 0; checked( boolval( $widget_calendar ), true, true ); ?> value="1"><span class="description">是否移除小工具日历模块</span></td>
            </tr>
            <tr id="widget_tag_cloud">
			<th><label for="widget_tag_cloud">移除标签云</label></th>
			<td><input type="checkbox" id="widget_tag_cloud" name="wp_optimize_option[widget_tag_cloud]" <?php $widget_tag_cloud = isset($options['widget_tag_cloud']) ? $options['widget_tag_cloud'] : 0; checked( boolval( $widget_tag_cloud ), true, true ); ?> value="1"><span class="description">是否移除小工具标签云模块</span></td>
            </tr>
            <tr id="widget_media_gallery">
			<th><label for="widget_media_gallery">移除画廊</label></th>
			<td><input type="checkbox" id="widget_media_gallery" name="wp_optimize_option[widget_media_gallery]" <?php $widget_media_gallery = isset($options['widget_media_gallery']) ? $options['widget_media_gallery'] : 0; checked( boolval( $widget_media_gallery ), true, true ); ?> value="1"><span class="description">是否移除小工具画廊模块</span></td>
            </tr>
            <tr id="widget_custom_html">
			<th><label for="widget_custom_html">移除自定义 HTML</label></th>
			<td><input type="checkbox" id="widget_custom_html" name="wp_optimize_option[widget_custom_html]" <?php $widget_custom_html = isset($options['widget_custom_html']) ? $options['widget_custom_html'] : 0; checked( boolval( $widget_custom_html ), true, true ); ?> value="1"><span class="description">是否移除小工具自定义 HTML 模块</span></td>
            </tr>
            <tr id="widget_media_video">
			<th><label for="widget_media_video">移除视频</label></th>
			<td><input type="checkbox" id="widget_media_video" name="wp_optimize_option[widget_media_video]" <?php $widget_media_video = isset($options['widget_media_video']) ? $options['widget_media_video'] : 0; checked( boolval( $widget_media_video ), true, true ); ?> value="1"><span class="description">是否移除小工具视频模块</span></td>
            </tr>
            <tr id="widget_recent_posts">
			<th><label for="widget_recent_posts">移除近期文章</label></th>
			<td><input type="checkbox" id="widget_recent_posts" name="wp_optimize_option[widget_recent_posts]" <?php $widget_recent_posts = isset($options['widget_recent_posts']) ? $options['widget_recent_posts'] : 0; checked( boolval( $widget_recent_posts ), true, true ); ?> value="1"><span class="description">是否移除小工具最近文章模块</span></td>
            </tr>
            <tr id="widget_recent_comments">
			<th><label for="widget_recent_comments">移除近期评论</label></th>
			<td><input type="checkbox" id="widget_recent_comments" name="wp_optimize_option[widget_recent_comments]" <?php $widget_recent_comments = isset($options['widget_recent_comments']) ? $options['widget_recent_comments'] : 0; checked( boolval( $widget_recent_comments ), true, true ); ?> value="1"><span class="description">是否移除小工具最近评论模块</span></td>
            </tr>
            <tr id="widget_media_audio">
			<th><label for="widget_media_audio">移除音频</label></th>
			<td><input type="checkbox" id="widget_media_audio" name="wp_optimize_option[widget_media_audio]" <?php $widget_media_audio = isset($options['widget_media_audio']) ? $options['widget_media_audio'] : 0; checked( boolval( $widget_media_audio ), true, true ); ?> value="1"><span class="description">是否移除小工具音频模块</span></td>
            </tr>
            <tr id="widget_pages">
			<th><label for="widget_pages">移除页面</label></th>
			<td><input type="checkbox" id="widget_pages" name="wp_optimize_option[widget_pages]" <?php $widget_pages = isset($options['widget_pages']) ? $options['widget_pages'] : 0; checked( boolval( $widget_pages ), true, true ); ?> value="1"><span class="description">是否移除小工具页面模块</span></td>
            </tr>
            </tbody>
            </table>
            </div>
            <?php submit_button();?>
        </form>
        </div>
    </div>
    <style>
    .optimize-manage-wrap {
        padding: 12px 10px;
    }
    .optimize-manage-wrap h3 {
        margin: 0;
        font-size: 14px;
        cursor: default;
        padding: 12px 10px;
        background-color: #f1f1f1;
        border-bottom: 1px solid #f1f1f1;
    }
    .optimize-manage-wrap .optimize-option {
        padding-top:20px;
        padding-bottom:40px;
    }
    </style>
    <script>
    jQuery(document).ready(function($) {
        $('.optimize-option').hide();
        $('.optimize-option:first').fadeIn();
        $('.nav-tab-title a:first').addClass('nav-tab-active');
        $('.nav-tab-title a:first').attr("aria-current","page");
        $('.nav-tab-title a').click(function(e) {
            e.preventDefault();
            var options = e.currentTarget.dataset.id;
            $('.nav-tab-title a').removeClass('nav-tab-active');
            $('.nav-tab-title a').removeAttr("aria-current");
            $(this).addClass('nav-tab-active').blur();
            $(this).attr("aria-current","page");
            $('.optimize-option').hide();
            if( options == 'optimize' ) {
                $('.optimize-option:first').show();
            }
            $('#' + options + '-options').fadeIn();
        });
    });
    </script>
<?php }