<?php

if ( !defined( 'ABSPATH' ) ) exit;

if( get_optimize_option('wplogo') ) {
	add_action('admin_bar_menu', function ( $wp_admin_bar ) {
		$wp_admin_bar->remove_node('wp-logo');
	}, 99 );
}

if( get_optimize_option('help') ) {
	add_filter('screen_options_show_screen', function () {
		return false;
	});
    add_action('in_admin_header', function(){
		global $current_screen;
		$current_screen->remove_help_tabs();
	});
}

if( get_optimize_option('spam') ) {
	add_filter('preprocess_comment', function ( $incoming_comment ) {
		$pattern = '/[一-龥]/u';
		if( ! preg_match($pattern, $incoming_comment['comment_content']) ) {
			wp_die( "您的评论中必须包含汉字!" );
		}
		$pattern = '/[あ-んア-ン]/u';
		if( preg_match($pattern, $incoming_comment['comment_content']) ) {
			wp_die( "评论禁止包含日文!" );
		}
		return( $incoming_comment );
	});
}

if( get_optimize_option('trackbacks') ) {
	add_filter('xmlrpc_methods',function ( $methods ) {
		$methods['pingback.ping'] = '__return_false';
		$methods['pingback.extensions.getPingbacks'] = '__return_false';
		return $methods;
	});
	remove_action( 'do_pings', 'do_all_pings', 10 );
	remove_action( 'publish_post','_publish_post_hook',5 );
}

if( get_optimize_option('xml_rpc') ) {
	add_filter('xmlrpc_enabled', '__return_false');
}

if( get_optimize_option('open_sans') ) {
	add_action( 'init', function () {
		wp_deregister_style( 'open-sans' );
		wp_register_style( 'open-sans', false );
		wp_enqueue_style( 'open-sans','' );
	} );
	add_action('admin_print_styles', function () {
		wp_deregister_style( 'wp-editor-font' );
		wp_register_style( 'wp-editor-font', '' );
	});
	add_action('admin_head', function () {
		echo'<style type="text/css">body{ font-family: Microsoft YaHei, PingFang SC;}</style>';
	});
}

if( get_optimize_option('admin_bar') ) {
	add_filter( 'show_admin_bar', '__return_false' );
}

if( get_optimize_option('generator') ) {
	remove_action( 'wp_head', 'wp_generator' );
}

if( get_optimize_option('o_link') ) {
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
}

if( get_optimize_option('feed') ) {
	remove_action( 'wp_head', 'feed_links', 2 );// 文章和评论feed
	remove_action( 'wp_head', 'feed_links_extra', 3 );// 去除评论feed
	add_action('do_feed',      'wp_disable_feed_link', 1);
	add_action('do_feed_rdf',  'wp_disable_feed_link', 1);
	add_action('do_feed_rss',  'wp_disable_feed_link', 1);
	add_action('do_feed_rss2', 'wp_disable_feed_link', 1);
	add_action('do_feed_atom', 'wp_disable_feed_link', 1);
	function wp_disable_feed_link() {
		wp_die(__('<h1>不再提供 Feed，请访问网站<a href="'.get_bloginfo('url').'">首页</a>！</h1>'));
	}
}

if( get_optimize_option('emoji') ) {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
}

if( get_optimize_option('gravatar') ) {
	add_filter('get_avatar', function ($avatar, $id_or_email, $size){
		return str_replace(['cn.gravatar.com/avatar', 'secure.gravatar.com/avatar', '0.gravatar.com/avatar', '1.gravatar.com/avatar', '2.gravatar.com/avatar'], 'cdn.v2ex.com/gravatar', $avatar);
	}, 10, 3 );
}

if( get_optimize_option('oembed') ) {
	function wp_disable_embeds_init() {
		global $wp;
		$wp->public_query_vars = array_diff( $wp->public_query_vars, array(
			'embed',
		) );
		add_filter('rest_enabled', '__return_false');
		add_filter( 'embed_oembed_discover', '__return_false' );
		add_filter( 'rewrite_rules_array', 'wp_disable_embeds_rewrites' );
		add_filter( 'tiny_mce_plugins', 'wp_disable_embeds_tiny_mce_plugin' );
		remove_action( 'rest_api_init', 'wp_oembed_register_route' );
		remove_filter( 'oembed_dataparse', 'wp_filter_oembed_result', 10 );
		remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
		remove_action( 'wp_head', 'wp_oembed_add_host_js' );
		remove_action( 'wp_head', 'wp_resource_hints', 2 ); 
		remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
		remove_action( 'wp_head', 'wp_oembed_add_discovery_links', 10 );
	}
	add_action( 'init', 'wp_disable_embeds_init', 99 );
	function wp_disable_embeds_tiny_mce_plugin( $plugins ) {
		return array_diff( $plugins, array( 'wpembed' ) );
	}
	function wp_disable_embeds_rewrites( $rules ) {
		foreach ( $rules as $rule => $rewrite ) {
			if ( false !== strpos( $rewrite, 'embed=true' ) ) {
				unset( $rules[ $rule ] );
			}
		}
		return $rules;
	}
}

if( get_optimize_option('srcset') ) {
	add_filter( 'max_srcset_image_width', create_function('', 'return 1;') );
}

if( get_optimize_option('update_core') ) {
	add_filter('automatic_updater_disabled', '__return_true');
	add_filter('pre_site_transient_update_core', create_function('$a', "return null;"));
	wp_clear_scheduled_hook('wp_version_check');
	wp_clear_scheduled_hook('wp_maybe_auto_update');
	remove_action('admin_init', '_maybe_update_core'); 
	remove_action('init', 'wp_schedule_update_checks');
}

if( get_optimize_option('update_plugins') ) {
	add_filter('pre_site_transient_update_plugins', create_function('$a', "return null;"));
	wp_clear_scheduled_hook('wp_update_plugins');
	remove_action( 'load-plugins.php', 'wp_update_plugins' );
	remove_action( 'load-update.php', 'wp_update_plugins' );
	remove_action( 'load-update-core.php', 'wp_update_plugins' );
	remove_action( 'admin_init', '_maybe_update_plugins' ); 
}

if( get_optimize_option('update_themes') ) {
	add_filter('pre_site_transient_update_themes',  create_function('$a', "return null;"));
	wp_clear_scheduled_hook('wp_update_themes');
	remove_action( 'load-themes.php', 'wp_update_themes' );
	remove_action( 'load-update.php', 'wp_update_themes' );
	remove_action( 'load-update-core.php', 'wp_update_themes' );
	remove_action( 'admin_init', '_maybe_update_themes' ); 
}

if( get_optimize_option('welcome_panel') ) {
	remove_action('welcome_panel', 'wp_welcome_panel');
}

add_action('wp_dashboard_setup', function () {
	global $wp_meta_boxes;
	if( get_optimize_option('now') ) { unset( $wp_meta_boxes['dashboard']['normal']['core']['dashboard_right_now'] ); }
	if( get_optimize_option('activity') ) { unset( $wp_meta_boxes['dashboard']['normal']['core']['dashboard_activity'] ); }
	if( get_optimize_option('quick') ) { unset( $wp_meta_boxes['dashboard']['side']['core']['dashboard_quick_press'] ); }
	if( get_optimize_option('income') ) { unset( $wp_meta_boxes['dashboard']['normal']['core']['dashboard_incoming_links'] ); }
	if( get_optimize_option('site_health') ) { unset( $wp_meta_boxes['dashboard']['normal']['core']['dashboard_site_health'] ); }
	if( get_optimize_option('recent') ) { unset( $wp_meta_boxes['dashboard']['normal']['core']['dashboard_recent_comments'] ); }
	if( get_optimize_option('drafts') ) { unset( $wp_meta_boxes['dashboard']['side']['core']['dashboard_recent_drafts'] ); }
	if( get_optimize_option('primary') ) { unset( $wp_meta_boxes['dashboard']['side']['core']['dashboard_primary'] ); }
	if( get_optimize_option('secondary') ) { unset( $wp_meta_boxes['dashboard']['side']['core']['dashboard_secondary'] ); }
});

add_action( 'widgets_init', function () {
	if( get_optimize_option('widget_rss') ) { unregister_widget('WP_Widget_RSS'); }
	if( get_optimize_option('widget_categories') ) { unregister_widget('WP_Widget_Categories'); }
	if( get_optimize_option('widget_meta') ) { unregister_widget('WP_Widget_Meta'); }
	if( get_optimize_option('widget_media_image') ) { unregister_widget('WP_Widget_Media_Image'); }
	if( get_optimize_option('widget_nav_menu') ) { unregister_widget('WP_Nav_Menu_Widget'); }
	if( get_optimize_option('widget_search') ) { unregister_widget('WP_Widget_Search'); }
	if( get_optimize_option('widget_text') ) { unregister_widget('WP_Widget_Text'); }
	if( get_optimize_option('widget_archives') ) { unregister_widget('WP_Widget_Archives'); }
	if( get_optimize_option('widget_calendar') ) { unregister_widget('WP_Widget_Calendar'); }
	if( get_optimize_option('widget_tag_cloud') ) { unregister_widget('WP_Widget_Tag_Cloud'); }
	if( get_optimize_option('widget_media_gallery') ) { unregister_widget('WP_Widget_Media_Gallery'); }
	if( get_optimize_option('widget_custom_html') ) { unregister_widget('WP_Widget_Custom_HTML'); }
	if( get_optimize_option('widget_media_video') ) { unregister_widget('WP_Widget_Media_Video'); }
	if( get_optimize_option('widget_recent_posts') ) { unregister_widget('WP_Widget_Recent_Posts'); }
	if( get_optimize_option('widget_recent_comments') ) { unregister_widget('WP_Widget_Recent_Comments'); }
	if( get_optimize_option('widget_media_audio') ) { unregister_widget('WP_Widget_Media_Audio'); }
	if( get_optimize_option('widget_pages') ) { unregister_widget('WP_Widget_Pages'); }
}, 11 );