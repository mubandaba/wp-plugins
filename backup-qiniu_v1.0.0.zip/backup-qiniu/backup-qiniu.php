<?php  
/*
Plugin Name: 七牛云备份
Plugin URI: http://www.beizigen.com
Description: 将网站文件、数据库定时备份到七牛云存储。
Version: 1.0.0
Author: 背字根
Author URI: http://www.beizigen.com
*/
require_once('func.php');

// 清除定时任务
function bzg_backup_qiniu_clear_cron() {
	wp_clear_scheduled_hook( 'backup_qiniu' );
}
register_deactivation_hook( __FILE__, 'bzg_backup_qiniu_clear_cron' );
register_uninstall_hook( __FILE__, 'bzg_backup_qiniu_clear_cron' );

// 定时任务挂钩
add_action( 'backup_qiniu', 'bzg_backup_qiniu_cron' );

function bzg_backup_qiniu_control() {
	if( isset( $_POST['action'] ) && $_POST['action'] == '保存设置' ) {
		$path = $_POST['path'];
		if( is_array( $path ) )
			$path = implode(',', $path);
		$updatas = array(
			'cycle' => $_POST['cycle'],
			'number' => $_POST['number'],
			'isfile' => $_POST['isfile'],
			'isdb' => $_POST['isdb'],
			'path' => $path,
			'AccessKey' => trim($_POST['AccessKey']),
			'SecretKey' => trim($_POST['SecretKey']),
			'Bucket_Name' => trim($_POST['Bucket_Name']),
		);
		$updatas = serialize($updatas);
		update_option('backup_qiniu', $updatas);
		
		// 添加定时任务
		if( ! wp_next_scheduled( 'backup_qiniu' ) ) {
			$the_time = current_time( 'timestamp' );
			$the_time = date('Y-m-d', $the_time);
			$the_time = strtotime( $the_time ) + 10800;
			$timezone_offet = get_option('gmt_offset')*3600;
			$the_time = $the_time - $timezone_offet;
			wp_schedule_event( $the_time, 'daily', 'backup_qiniu');
		}
	
		echo '<div id="message" class="updated fade">设置已保存！</div>';
	}
	
	if( isset( $_POST['action'] ) && $_POST['action'] == '手动备份' ) {
		bzg_backup_qiniu_start();
		echo '<div id="message" class="updated fade">备份成功，赶紧登录七牛云存储查看一下吧！</div>';
	}
	
	$options = get_option('backup_qiniu');
	$options = unserialize($options);
	
?>
<style type="text/css">
#message {
	padding: 1em;
}
#dirlist {
	padding: 20px;
	background-color: #ffffff;
	max-width: 400px;
	max-height: 300px;
	overflow: auto;
	border: 1px solid #dddddd;
	display: none;
}
#dirlist .child {
	margin: 1em 2em;
	display: none;
}
#dirlist li span {
	margin-left: 3px;
	font-size: 1em;
	height: 1em;
	width: 1em;
	vertical-align: middle;
}

#qiniu-settings .show {
	display: block;
}
</style>
<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery('#dirlist input:checked').each(function() {
			var parent = jQuery(this).parent().parent().parent();
			if(parent.hasClass('child')) {
				if(parent.hasClass('depth-1')) {
					parent.addClass('show');
					parent.parent().find('span').removeClass('dashicons-plus-alt').addClass('dashicons-minus');
				}
				if(parent.hasClass('depth-2')) {
					parent.addClass('show');
					parent.parent().parent().addClass('show');
					parent.parent().find(' > span').removeClass('dashicons-plus-alt').addClass('dashicons-minus');
					parent.parent().parent().parent().find(' > span').removeClass('dashicons-plus-alt').addClass('dashicons-minus');
				}
			}
			
		});
		
		jQuery('#dirlist li span').click(function(){
			if( jQuery(this).hasClass('dashicons-plus-alt') ) {
				jQuery(this).parent().find(' > .child').slideDown();
				jQuery(this).removeClass('dashicons-plus-alt').addClass('dashicons-minus');
			} else {
				jQuery(this).parent().find(' > .child').slideUp();
				jQuery(this).removeClass('dashicons-minus').addClass('dashicons-plus-alt');
			}	
		});
		jQuery('#isfile').change(function(){
			if( jQuery(this).val() == 'yes' ) {
				jQuery(this).parent().find('#dirlist').slideDown();
			} else {
				jQuery(this).parent().find('#dirlist').slideUp();
			}
		});
	});
</script>
<div id="qiniu-settings" class="wrap">
	<h2>WordPress七牛云备份</h2>
	<p>请确保七牛云存储Bucket访问控制设置为私有空间，以保障您的数据安全。如果觉得插件好用，请使用我的<a href="https://portal.qiniu.com/signup?code=3lcthqn5li82a" target="_blank">邀请链接注册七牛</a>，以便获得免费技术支持，谢谢！</p>
	<form method="post" action="">
		<table class="form-table">
			<tbody>
				<tr>
					<th scope="row"><label for="cycle">备份周期</label></th>
					<td>
						<select name="cycle" id="cycle">
							<option value="day"<?php echo $options['cycle'] == 'day' ? ' selected="selected"' : ''; ?>>每天</option>
							<option value="week"<?php echo $options['cycle'] == 'week' || ! $options['cycle'] ? ' selected="selected"' : ''; ?>>每周</option>
							<option value="month"<?php echo $options['cycle'] == 'month' ? ' selected="selected"' : ''; ?>>每月</option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="number">保留份数</label></th>
					<td>
						<select name="number" id="number">
							<option value="1"<?php echo $options['number'] == 1 ? ' selected="selected"' : ''; ?>>1份</option>
							<option value="3"<?php echo $options['number'] == 3 ? ' selected="selected"' : ''; ?>>3份</option>
							<option value="7"<?php echo $options['number'] == 7 ? ' selected="selected"' : ''; ?>>7份</option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="isdb">备份数据库</label>
					</th>
					<td>
						<select id="isdb" name="isdb">
							<option value="yes"> 是 </option>
							<option value="no"<?php echo $options['isdb'] == 'no' ? ' selected="selected"' : ''; ?>> 否 </option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="isfile">备份文件</label>
					</th>
					<td>
						<select id="isfile" name="isfile">
							<option value="no"> 否 </option>
							<option value="yes"<?php echo $options['isfile'] == 'yes' ? ' selected="selected"' : ''; ?>> 是 </option>
						</select>
						<ul id="dirlist" <?php echo $options['isfile'] == 'yes' ? ' class="show"' : ''; ?>>
						<?php
							$path = ABSPATH;
							$dirlist = explode(',', $options['path']);
							bzg_backup_qiniu_dirlist( $path, $dirlist );
						?>
						</ul>
						<p class="description">选择要备份的目录，可以是多个</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="AccessKey">AccessKey</label>
					</th>
					<td>
						<input id="AccessKey" name="AccessKey" class="regular-text code" type="text" value="<?php echo $options['AccessKey']; ?>" />
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="SecretKey">SecretKey</label>
					</th>
					<td>
						<input id="SecretKey" name="SecretKey" class="regular-text code" type="text" value="<?php echo $options['SecretKey']; ?>" />
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="Bucket_Name">Bucket Name</label>
					</th>
					<td>
						<input id="Bucket_Name" name="Bucket_Name" class="regular-text code" type="text" value="<?php echo $options['Bucket_Name']; ?>" />
					</td>
				</tr>
			</tbody>		
		</table>
		<p><input class="button-primary" name="action" type="submit" value="保存设置" /></p>
		<p class="description">你也可以立即执行备份，手动备份不影响你的定时备份功能</p>
		<p><input class="button" type="submit" name="action" value="手动备份" /></p>
	</form>
</div>

<?php
} 
//添加菜单
function bzg_backup_qiniu_menu() {
	if ( function_exists('add_options_page') )
		add_options_page( 'WordPress七牛云备份', '七牛云备份', 'administrator', 'backup_qiniu', 'bzg_backup_qiniu_control' );
}
add_action('admin_menu', 'bzg_backup_qiniu_menu');

function bzg_backup_qiniu_settings_link( $action_links, $plugin_file ) {
	if( $plugin_file == plugin_basename(__FILE__) ){
		$settings_link = '<a href="options-general.php?page=backup_qiniu">设置</a>';
		array_unshift( $action_links, $settings_link );
	}
	return $action_links;
}
add_filter( 'plugin_action_links', 'bzg_backup_qiniu_settings_link', 10, 2 );
?>