<p>
	<?php _e('Use a built-in or custom taxonomy to create a list of relevant keywords that describe the topic of the news article.','xml-sitemap-feed'); ?>
</p>
