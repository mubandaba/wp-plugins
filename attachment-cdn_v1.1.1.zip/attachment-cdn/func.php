<?php

$attachment_cdn_options = get_option( 'attachment_cdn_options' );
$attachment_cdn_options = unserialize($attachment_cdn_options);

//创建任务
function bzg_attachment_cdn_add_cron() {
	$timestamp = time();
	$timestamp = $timestamp-3599;
	if( ! wp_next_scheduled( 'attachment_cdn_cron' ) ) {
		wp_schedule_event( $timestamp, 'hourly', 'attachment_cdn_cron');
		return true;
	} else {
		return false;
	}
}

//删除任务
function bzg_attachment_cdn_delete_cron() {
	if( wp_next_scheduled( 'attachment_cdn_cron' ) ) 
		wp_clear_scheduled_hook( 'attachment_cdn_cron' );
}

//给CURL添加参数，
function bzg_api_curl(&$handle) {
	$url = get_bloginfo( 'url' );
	$url = parse_url( $url );
	curl_setopt( $handle, CURLOPT_REFERER, $url['host'] );
}
//获取WordPress所有图片ID
function bzg_attachment_cdn_get_attachment_ids(){
	$ids = array();
	$args = array(
		'posts_per_page' => -1,
		'post_type' => 'attachment',
		'post_status' => 'closed',
	);
	$query = new WP_Query( $args );
	while ( $query->have_posts() ) {
		$query->the_post();
		$ids[] = get_the_ID();
	}
	wp_reset_postdata();
	return $ids;
}

function bzg_attachment_cdn_cron_fun() {
	global $attachment_cdn_options;
	$attachment_ids = get_option( 'attachment_cdn_ids' );
	$blogname = get_bloginfo( 'name' );
	$adminemail = get_bloginfo('admin_email');
	$options = $attachment_cdn_options;
	
	if( ! empty( $attachment_ids ) )
		$attachment_ids = explode( ',', $attachment_ids );
	
	if( empty( $attachment_ids ) )
		$attachment_ids = bzg_attachment_cdn_get_attachment_ids();

	if( empty( $attachment_ids ) ) {
		bzg_attachment_cdn_delete_cron();
		//发邮件
		$mail_title = $blogname . '上传图片到云存储失败';
		$mail_txt = $mail_title . " \n";
		$mail_txt .= '失败原因可能是图片不存在，如有问题请联系QQ80058951反馈。';
		$headers[] = 'From: '. $blogname .' < ' . $adminemail . '>';
		wp_mail( $blogname . ' <' . $adminemail . '>', $mail_title, $mail_txt, $headers );
		exit;
	}
	
	$up_ids = $attachment_ids;
	set_time_limit(0);
	add_action( 'http_api_curl', 'bzg_api_curl', 10, 1 );
	$error_id = '';
	if($options['backupcdn']) $backup_url = $options['backupcdnscheme'] . '://' . $options['backupcdn'];
	$upload_path = get_option( 'upload_path');
	if(empty($upload_path) ) $upload_path = 'wp-content/uploads';
	
	foreach ( $attachment_ids as $attachment_id ) {
		$meta = wp_get_attachment_metadata( $attachment_id );
		$upload_dir = wp_upload_dir( $meta['file'] );
		
		$originalfile = $upload_dir['basedir'] . '/' . $meta['file'];
		if( file_exists( $originalfile ) ) {
			$originalurl = $upload_dir['baseurl'] . '/' . $meta['file'];
			$original_response = wp_remote_get( $originalurl, array( 'timeout' => 30 ) );
			if($backup_url) {
				$originalurl2 = $backup_url . '/' . $upload_path . '/' . $meta['file'];
				wp_remote_get( $originalurl2, array( 'timeout' => 30 ) );
			}
			if ( is_wp_error( $original_response ) ) {
				$error_id .= $attachment_id . " \n";
			} elseif( $options['delfile'] == 'yes' ) {
				unlink( $originalfile );
			}
		}
		
		$sizes = $meta['sizes'];
		if( ! empty( $sizes ) ) {
			foreach( $sizes as $size ) {
				if( empty( $size['file'] ) )
					continue;
				
				$sizefile = $upload_dir['path'] . '/' . $size['file'];
			
				if( ! file_exists( $sizefile ) )
					continue;
				
				$sizeurl = $upload_dir['url'] . '/' . $size['file'];
				$sizeurl_response = wp_remote_get( $sizeurl, array( 'timeout' => 30 ) );
				if($backup_url) {
					$sizeurl2 = $backup_url . '/' . $upload_path . $upload_dir['subdir'] . '/' . $size['file'];
					wp_remote_get( $sizeurl2, array( 'timeout' => 30 ) );
				}
				if ( is_wp_error( $sizeurl_response ) ) {
					$error_id .= $attachment_id . "(缩略图) \n";
				} elseif( $options['delfile'] == 'yes' ) {
					unlink( $sizefile );
				}
			}
		}
		
		$unset_key = array_search( $attachment_id, $up_ids );
		unset( $up_ids[$unset_key] );
		$up_id = implode( ',', $up_ids );
		update_option( 'attachment_cdn_ids', $up_id );
	}
	
	delete_option( 'attachment_cdn_ids' );
	bzg_attachment_cdn_delete_cron();
	
	//发邮件
	$mail_title = $blogname . '上传图片到云存储任务执行完成';
	$mail_txt = $mail_title . " \n";
	if( ! empty( $error_id ) )
		$mail_txt .= '上传失败图片：' . $error_id;
	
	$mail_txt .= '请登录云存储平台检查图片是否都已上传，如有问题请联系QQ80058951反馈。';
	$headers[] = 'From: '. $blogname .' < ' . $adminemail . '>';
	wp_mail( $blogname . ' <' . $adminemail . '>', $mail_title, $mail_txt, $headers );
}
add_action( 'attachment_cdn_cron', 'bzg_attachment_cdn_cron_fun' );

//替换URL
function bzg_attachment_cdn_replace_url( $content, $order = 'ASC' ) {
	
	if( ! $cdn_url = get_option( 'upload_url_path' ) )
		return $content;
	
	$siteurl = get_option( 'siteurl' );
	$siteurl = trailingslashit( $siteurl );
	$upload_path = trim( get_option( 'upload_path' ) );
	if ( empty( $upload_path ) || ( 'wp-content/uploads' == $upload_path ) )
		$localurl = WP_CONTENT_URL . '/uploads';
	else
		$localurl = $siteurl . $upload_path;
	
	if( $order == 'ASC' )
		$content = str_replace( $localurl, $cdn_url, $content );
	
	if( $order == 'DESC' )
		$content = str_replace( $cdn_url, $localurl, $content );
	
	return $content;
}

//上传图片时将镜像URL替换为本地URL
function bzg_attachment_cdn_insert_attachment_data( $data, $postarr ) {
	$guid = $postarr['guid'];
	$url = bzg_attachment_cdn_replace_url( $guid, 'DESC' );
	$data['guid'] = $url;
	return $data;
}
add_filter( 'wp_insert_attachment_data', 'bzg_attachment_cdn_insert_attachment_data', 10, 2 );

//保存附件数据时执行同步图片
function bzg_attachment_cdn_update_attachment_metadata( $data ) {
	global $attachment_cdn_options;
	add_action( 'http_api_curl', 'bzg_api_curl', 10, 1 );
	$meta = $data;
	$options = $attachment_cdn_options;
	if($options['backupcdn']) $backup_url = $options['backupcdnscheme'] . '://' . $options['backupcdn'];
	$upload_dir = wp_upload_dir( $meta['file'] );
	$upload_path = get_option( 'upload_path');
	if(empty($upload_path) ) $upload_path = 'wp-content/uploads';
	
	$originalfile = $upload_dir['basedir'] . '/' . $meta['file'];
	if( file_exists( $originalfile ) ) {
		$originalurl = $upload_dir['baseurl'] . '/' . $meta['file'];
		$original_response = wp_remote_get( $originalurl, array( 'timeout' => 30 ) );
		if($backup_url) {
			$originalurl2 = $backup_url . '/' . $upload_path . '/' . $meta['file'];
			wp_remote_get( $originalurl2, array( 'timeout' => 30 ) );
		}
		if( ! is_wp_error( $original_response ) && $options['delfile'] == 'yes' )
			unlink( $originalfile );
	}
	
	$sizes = $meta['sizes'];
	if( ! empty( $sizes ) ) {
		foreach( $sizes as $size ) {
			if( empty( $size['file'] ) )
				continue;
			
			$sizefile = $upload_dir['path'] . '/' . $size['file'];
			
			if( ! file_exists( $sizefile ) )
				continue;
			
			$sizeurl = $upload_dir['url'] . '/' . $size['file'];
			$sizeurl_response = wp_remote_get( $sizeurl, array( 'timeout' => 30 ) );
			if($backup_url) {
				$sizeurl2 = $backup_url . '/' . $upload_path . $upload_dir['subdir'] . '/' . $size['file'];
				wp_remote_get( $sizeurl2, array( 'timeout' => 30 ) );
			}
			if( ! is_wp_error( $sizeurl_response ) && $options['delfile'] == 'yes' )
				unlink( $sizefile );
		}
	}
	return $data;
}
add_filter( 'wp_update_attachment_metadata', 'bzg_attachment_cdn_update_attachment_metadata', 10, 2 );

//保存文章时把镜像URL替换为本地URL
function bzg_attachment_cdn_content_save( $content ) {
	$content = bzg_attachment_cdn_replace_url( $content, 'DESC' );
	return $content;
}
add_filter( 'content_save_pre', 'bzg_attachment_cdn_content_save', 10, 1 );

//过滤前台URL地址
if( $attachment_cdn_options['themefile'] == 'yes' && ! is_admin() ) {
	
	//前台URL替换
	function bzg_attachment_cdn_ob_replace( $html ) {
		global $attachment_cdn_options;
		
		//替换本地附件
		$html = bzg_attachment_cdn_replace_url( $html );
		$siteurl = get_option( 'siteurl' );
		$siteurl = untrailingslashit( $siteurl );
		$siteurl = str_replace( '/', '\/', $siteurl );
		$upload_url_path = get_option( 'upload_url_path' );
		$parse_url = parse_url( $upload_url_path );
		$cdn_url = $attachment_cdn_options['cdnscheme'] . '://' . $parse_url['host'];
		$suffix = 'js|css|jpg|jpeg|gif|png';
		//替换主题URL
		$themename = get_template();
		$html = preg_replace( "/$siteurl(\/wp-content\/themes\/$themename\/.+\.(?:$suffix))/U", $cdn_url . '$1', $html );
		//替换WP自带JS和CSS
		$html = preg_replace( "/$siteurl(\/wp-includes\/.+\.(?:$suffix))/U", $cdn_url . '$1', $html );
		
		return $html;
	}
	function bzg_attachment_cdn_ob_start() {
		ob_start( 'bzg_attachment_cdn_ob_replace' );
	}
	add_action( 'wp_loaded', 'bzg_attachment_cdn_ob_start' );
	
} elseif( ! is_admin() ) {
	
	//前台文章内容输出镜像URL
	function bzg_attachment_the_content( $content ) {
		$content = bzg_attachment_cdn_replace_url( $content );
		return $content;
	}
	add_filter( 'the_content', 'bzg_attachment_the_content', 10, 1 );
	function bzg_attachment_replace( $url ) {
		global $attachment_cdn_options;
		$parse = parse_url( $url );
		$url = str_replace($parse['scheme'], $attachment_cdn_options['cdnscheme'], $url);
		return $url;
	}
	add_filter('wp_get_attachment_url', 'bzg_attachment_replace', 10, 1 );
}

//过滤后台文章内容
if( $attachment_cdn_options['attachment_delfile'] == 'yes' ) {
	add_filter( 'content_edit_pre', 'bzg_attachment_the_content', 10, 1 );
}

//要阻止的代理
function bzg_attachment_agent( $str ) {
	//代理列表
	$agents = array( 'tencent-httputils', 'qiniu-imgstg-spider' );
	$res = false;
	foreach( $agents as $agent ) {
		if( stripos( $str, $agent ) !== false )
			$res = true;
	}
	return $res;
}
function bzg_attachment_send_headers() {
	
	$agent = $_SERVER['HTTP_USER_AGENT'];

	if( bzg_attachment_agent( $agent ) ) {
		header( 'HTTP/1.1 503 Service Temporarily Unavailable' );
		exit;
	}
}

if( $attachment_cdn_options['attachment_cdn_html'] != 'yes' )
	add_action( 'send_headers', 'bzg_attachment_send_headers' );
?>