<p>
	<?php _e('When you are done configuring and preparing your news content and you are convinced your site adheres to the <a href="https://support.google.com/news/publisher/answer/40787" target="_blank">Google News guidelines</a>, go ahead and <a href="https://partnerdash.google.com/partnerdash/d/news" target="_blank">submit your site for inclusion</a>!','xml-sitemap-feed'); ?> 
	<?php _e('It is strongly recommended to submit your news sitemap to your Google Webmasters Tools account to monitor for warnings or errors.','xml-sitemap-feed'); ?>
</p>
