<?php
/*
 * Plugin Name: 小宇宙
 * Plugin URI: https://www.wpxyz.com.cn
 * Author: 魏星
 * Plugin URI: https://www.wpxyz.com.cn
 * Version: 1.0.0
 */

# 插件常量
define('WPXYZ_VERSION', '1.0.0');
define('WPXYZ_SITE_URL', get_bloginfo('url') ) ;
define('WPXYZ_PATH', plugin_dir_path( __FILE__ ) ) ;
define('WPXYZ_URL',  plugin_dir_url( __FILE__ )  ) ;
define('WPXYZ_STATIC_URL', WPXYZ_URL.'static/' );
define('WPXYZ_IMG_URL'   , WPXYZ_STATIC_URL.'img/' );
define('WPXYZ_JS_URL'    , WPXYZ_STATIC_URL.'js/' );
define('WPXYZ_CSS_URL'   , WPXYZ_STATIC_URL.'css/' );

# 核心函数
include "inc/lab.php";



if(WPXYZ_is_actived()) {
    include "inc/tdk-functions.php";
    include "inc/sitemap-functions.php";
    include "inc/optimize-functions.php";
    include "inc/push-functions.php";
}


register_activation_hook( __FILE__, 'TDK_default' );
