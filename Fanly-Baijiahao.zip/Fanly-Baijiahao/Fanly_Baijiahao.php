<?php
/*
Plugin Name: Fanly Baijiahao
Plugin URI: https://zhan.leiue.com/fanly-baijiahao.html
Description: Fanly Baijiahao 是一款可以将WordPress文章同步到百家号的插件，支持自定义文章类型、定时文章及延迟同步等丰富功能。
Version: 1.1
Author: Fanly
Author URI: https://zhangzifan.com
*/

//Fanly Baijiahao
add_action('init', 'FanlyBaijiahao', 100);
function FanlyBaijiahao() { // 自定义文章类型
	$Fanly = get_option('Fanly_Baijiahao');//获取选项
	if ( is_array(@$Fanly['Types']) ) {
		foreach($Fanly['Types'] as $type) {
			add_action('save_'.$type, 'fanly_baijiahao');
		}
	} 
} 
// main
function fanly_baijiahao($post_id, $Delay=false) {
	//参数获取
	$Fanly				= get_option('Fanly_Baijiahao');//获取选项
	//文章信息
	$get_post_info		= get_post($post_id );
	$get_post_title		= $get_post_info->post_title;//标题
	$get_post_content	= $get_post_info->post_content;//内容
	$get_post_link		= get_permalink($post_id);//文章链接
	$get_post_status	= $get_post_info->post_status;//文章状态
	
	//设置状态
	if(isset($_POST['bjh']) && substr(get_post_meta($post_id ,'Fanly_Baijiahao',true),0,4)!='http'){
		if($_POST['bjh']==2){update_post_meta($post_id , 'Fanly_Baijiahao', 2);}//立刻
		elseif($_POST['bjh']==1 && isset($_POST['bjh_time']) && strtotime($_POST['bjh_time']) && strtotime($_POST['bjh_time'])>time()){//自定义延迟时间
			date_default_timezone_set(get_option('timezone_string'));
			update_post_meta($post_id , 'Fanly_Baijiahao', strtotime($_POST['bjh_time']));}
		elseif($_POST['bjh']==1 && !isset($_POST['bjh_time'])){update_post_meta($post_id , 'Fanly_Baijiahao', 1);}//固定延迟时间
		elseif($Fanly['Sync']){update_post_meta($post_id , 'Fanly_Baijiahao', 0);}
	}
	
	if( @$Fanly['Delay'] && ($get_post_status=='publish' || $get_post_status=='future') && !$Delay ){
		if( isset($_POST['bjh']) && $_POST['bjh']==1 ){
			if( isset($_POST['bjh_time']) ){
				$time = get_post_meta($post_id ,'Fanly_Baijiahao',true);
				$time = $time>=time() ? $time : time() + $Fanly['Delay'] * 60;
			}else{
				$time = time() + $Fanly['Delay'] * 60;
			}
			wp_clear_scheduled_hook( 'fanly_baijiahao_publish', array( $post_id  ) );
			wp_schedule_single_event( $time, 'fanly_baijiahao_publish', array( $post_id  ) );
		}else{
			wp_clear_scheduled_hook( 'fanly_baijiahao_publish', array( $post_id  ) );
		}
	}
	//判断是否同步
	if( $Delay || //延迟
		(	isset($_POST['bjh']) &&
			$_POST['bjh'] == 2 && 
			$get_post_status == 'publish'
		) || (	
			isset($_POST['rebjh']) &&
			$get_post_status == 'publish'
		) || (
			!isset($_POST['bjh']) &&
			$get_post_status == 'publish' &&
		 	get_post_meta($post_id ,'Fanly_Baijiahao',true)==2 //定时文章 立刻
		)
	  ) {
		  
		// 封面图片
		$cover_images = array();
		preg_match_all('/<img .*?src=[\"|\'](.+?)[\"|\'].*?>/', $get_post_content, $strResult, PREG_PATTERN_ORDER);  
		$n = count($strResult[1]);  
		if($n > 0){ // 提取首图
			if($n >= 3){
				$cover_arr = array(
					array('src' => $strResult[1][0]),
					array('src' => $strResult[1][1]),
					array('src' => $strResult[1][2]),
				);
				$cover_images = json_encode($cover_arr);
			}else{
				$cover_arr = array(
					array('src' => $strResult[1][0]),
				);
				$cover_images = json_encode($cover_arr);
			}
        }
		
		$Copy		= $Fanly['Copy'] !== '' ? '<p>'.stripslashes($Fanly['Copy']).'</p>' : '';
		$content	= apply_filters( 'the_content', $get_post_content ) . $Copy;
		$is_original= get_post_meta($post_id ,'Fanly_Submit',true)=='Original' ? 1 : 0;
		$article_id	= get_post_meta($post_id ,'Fanly_Baijiahao',true);
		
		//参数
		$arrs = array(//发布
			'app_id'		=> $Fanly['app_id'],	//作者帐号ID
			'app_token'		=> $Fanly['app_token'],	//授权密钥
			'title'			=> $get_post_title,		//文章标题，限定8-40个中英文字符以内
			'content'		=> $content,			//正文内容，限制20000个中英文字符内，富文本
			'origin_url'	=> $get_post_link,		//原文地址
			'cover_images'	=> $cover_images,		//文章封面图片地址url, 0-3张封面图，封面图尺寸不小于218*146，没有封面图的内容将会进入草稿
			'is_original'	=> $is_original,		//标定是否原创，1 为原创，0 为非原创
		);
		$republish = array(//重新发布
			'app_id'		=> $Fanly['app_id'],	//作者帐号ID
			'app_token'		=> $Fanly['app_token'],	//授权密钥
			'title'			=> $get_post_title,		//文章标题，限定8-40个中英文字符以内
			'content'		=> $content,			//正文内容，限制20000个中英文字符内，富文本
			'cover_images'	=> $cover_images,		//文章封面图片地址url
			'article_id'	=> str_replace('draw','',$article_id),		//需要修改的文章ID
		);
		$withdraw = array(//撤回
			'app_id'		=> $Fanly['app_id'],	//作者帐号ID
			'app_token'		=> $Fanly['app_token'],	//授权密钥
			'article_id'	=> $article_id,		//需要修改的文章ID
		);
		  
		//API
		$api			= 'http://baijiahao.baidu.com/builderinner/open/resource/article/publish';//发布
		$api_republish	= 'http://baijiahao.baidu.com/builderinner/open/resource/article/republish';//重新发布
		$api_withdraw	= 'http://baijiahao.baidu.com/builderinner/open/resource/article/withdraw';//撤回
		
		//
		$key = 'OK';
		
		if(substr($article_id,0,4)=='draw'){//重新发布
			$api	= $api_republish;
			$arrs	= $republish;
		}
		if($_POST['rebjh']=='2'&&substr($article_id,0,2)=='OK'){//撤回
			$api	= $api_withdraw;
			$arrs	= $withdraw;
			$key	= 'draw';
		}

		//执行
		$remote = wp_remote_post($api, array(
			'body'		=> json_encode($arrs),
		));
		
		//判断
		if ( is_wp_error( $remote ) ) {
			update_post_meta($post_id, 'Fanly_Baijiahao', '-1');
			$Fanly['msg'] = $remote->get_error_message();//错误信息
			update_option('Fanly_Baijiahao', $Fanly);//更新选项
		} else {
			$res = json_decode($remote['body'], true);
			if($res['errno']==0 && $res['data']['article_id']){
				update_post_meta($post_id, 'Fanly_Baijiahao', $key.$res['data']['article_id']);//OK
			}else{
				update_post_meta($post_id, 'Fanly_Baijiahao', '-1');
				$Fanly['msg'] = 'Error: '.$res['errno'].', '.$res['errmsg'];//错误信息
				update_option('Fanly_Baijiahao', $Fanly);//更新选项
			}
		}
		
    }
}

//延迟同步
add_action( 'fanly_baijiahao_publish', 'fanly_baijiahao_single_event', 10, 1 );
function fanly_baijiahao_single_event( $postid ) {
	fanly_baijiahao($postid, true);// do
}

//获取当前文章类型
function fanly_baijiahao_get_post_type() {
  global $post, $typenow, $current_screen;
  if ( $post && $post->post_type ) {return $post->post_type;}
  elseif ( $typenow ) {return $typenow;}
  elseif ( $current_screen && $current_screen->post_type ) {return $current_screen->post_type;}
  elseif ( isset( $_REQUEST['post_type'] ) ) {return sanitize_key( $_REQUEST['post_type'] );}
  elseif ( isset( $_REQUEST['post'] ) ) {return get_post_type( $_REQUEST['post'] );}
  return 'post';
}

//同步
add_action( 'admin_menu', 'Fanly_Baijiahao_Create' );
function Fanly_Baijiahao_Create(){
	$Fanly = get_option('Fanly_Baijiahao');//获取选项
	if(is_array($Fanly['Types']) && in_array(fanly_baijiahao_get_post_type(),$Fanly['Types'])){
		add_action( 'post_submitbox_misc_actions', 'Fanly_Baijiahao_to_publish_metabox' );//同步选项
	}
}
add_action( 'add_meta_boxes', 'fanly_baijiahao_register_meta_boxes' );
function fanly_baijiahao_register_meta_boxes() {
	global $post_id;
	if(	class_exists( 'Classic_Editor' ) && (
		(get_option('classic-editor-replace')=='classic' && get_option('classic-editor-allow-users')=='disallow') ||
		(get_option('classic-editor-allow-users')=='allow' && get_post_meta($post_id ,'classic-editor-remember',true)=='classic-editor')
	))return;
	$Fanly = get_option('Fanly_Baijiahao');//获取选项
	if(!is_array($Fanly['Types']))return;
	add_meta_box(
		'fanly-baijiahao-meta-box',
		'Fanly Baijiahao',
		'Fanly_Baijiahao_to_publish_metabox',
		$Fanly['Types'],
		$Fanly['Context'],
		'high',
		array(
			'__block_editor_compatible_meta_box' => true,
		)
	);
}
//同步选项
function Fanly_Baijiahao_to_publish_metabox() {
    global $post_id;
	$Fanly		= get_option('Fanly_Baijiahao');//获取选项
	$static		= get_post_meta($post_id,'Fanly_Baijiahao',true);
	//$link		= 'https://baijiahao.baidu.com/s?id='.str_replace('OK','',$static);
	$link		= 'https://baijiahao.baidu.com/builder/preview/s?id='.str_replace('OK','',$static);
	$checked	= $static==1 || time()<=$static || $Fanly['Sync']=='true' ? 'checked="checked"' : '';
	$realtime	= $static==2 ? 'checked="checked"' : '';
	$none		= $Fanly['Sync']!='true' && ($static=='' || $static==0) ? 'checked="checked"' : '';
	
	if(substr($static,0,2)=='OK'){
		$input = '<label class="selectit"><input name="rebjh" type="checkbox" value="2"> 撤回（已同步<a target="_blank" href="'.$link.'">查看</a>）</label>';
	}elseif(substr($static,0,4)=='draw'){
		$input = '<label class="selectit"><input name="bjh" type="checkbox" value="2"> 重新发布</label>';
	}elseif($static==-1){
		$err = $Fanly['msg'] ? ' [<a title="'.$Fanly['msg'].'"> ? </a>]' : '';
		$chk = $Fanly['Sync'] ? 'checked' : '';
		$input = '<label class="selectit"><input name="bjh" type="checkbox" value="2" '.$chk.'> 失败重试！</label>'.$err;
	}elseif(@$Fanly['Delay']){
		$timestamp = wp_next_scheduled( 'fanly_baijiahao_publish', array( $post_id  ) );
		date_default_timezone_set(get_option('timezone_string'));
		$tips = $timestamp ? ' title="'.date('Y/m/d H:i',$timestamp).'" style="color:#46b450;"' : '';
		$checked	= $timestamp ? 'checked="checked"' : $checked ;
		$realtime	= $timestamp ? '' : $realtime ;
		$none		= $timestamp ? '' : $none ;

		$input = '
		<label'.$tips.'><input type="radio" name="bjh" value="1" '.$checked.'>延迟 </label> 
		<label><input type="radio" name="bjh" value="2" '.$realtime.'>立刻 </label> 
		<label><input type="radio" name="bjh" value="0" '.$none.'>取消 </label> 
		';
	}else{
		$checked	= ($Fanly['Sync']=='true' && $static!=0) || ($Fanly['Sync']=='true' && $static=='') ? 'checked="checked"' : '';
		$input = '<label class="selectit"><input name="bjh" type="checkbox" value="2" '.$checked.'> 是否同步</label>';
	}
	echo '<div class="misc-pub-section misc-pub-post-status">百家号：<span id="bjh-span">'.$input.'</span></div>';
	if(substr($static,0,4)!='http' && $static!='-1' && @$Fanly['Delay'] && @$Fanly['reDelay']){
		//date_default_timezone_set(get_option('timezone_string'));
		$times = $timestamp ?: time()+$Fanly['Delay'] * 60;
		echo '<div id="bjhtime" class="misc-pub-section misc-pub-revisions">延迟:<span id="bjh-span">
	<label class="selectit"><input type="datetime-local" name="bjh_time" value="'.date('Y-m-d\TH:i',$times).'" style="min-width: 180px;padding: 0 3px;"></label>
	</span></div>';
	}
}

//add plugin link
add_filter( 'plugin_action_links', 'Fanly_Baijiahao_Add_Link', 10, 2 );
function Fanly_Baijiahao_Add_Link( $actions, $plugin_file ) {
	static $plugin;
	if (!isset($plugin))$plugin = plugin_basename(__FILE__);
	if ($plugin == $plugin_file) {
			$settings	= array('settings'	=> '<a href="options-general.php?page=Fanly_Baijiahao">' . __('Settings') . '</a>');
			$site_link	= array('support'	=> '<a href="https://zhangzifan.com" target="_blank">Fanly</a>');
			$actions 	= array_merge($settings, $actions);
			$actions	= array_merge($site_link, $actions);
	}
	return $actions;
}

// 更新检测
function FANLY_BJH_CHECK($refresh=''){
	$FANLY_BJH_CHECK = get_transient('FANLY_BJH_CHECK');
	if( $FANLY_BJH_CHECK === false || $refresh) {
		$response = wp_remote_get( 'https://zhan.leiue.com/?plugin=fanly-baijiahao', array('timeout' => 10) );
		if (!is_wp_error($response) && $response['response']['code'] == '200' ){
			$FANLY_BJH_CHECK = json_decode( $response['body'], true );
		}else{
			$FANLY_BJH_CHECK = '';
		}
		set_transient('FANLY_BJH_CHECK', $FANLY_BJH_CHECK, 86400);
	}
	return $FANLY_BJH_CHECK;
}


//插件设置菜单
add_action('admin_menu', 'fanly_baijiahao_menu'); 
function fanly_baijiahao_menu() {
	add_submenu_page('options-general.php','百家号同步设置', 'Fanly Baijiahao', 'manage_options', 'Fanly_Baijiahao','fanly_baijiahao_options', '');
} 
function fanly_baijiahao_options() {
//Refresh
if(isset($_POST['check_updated'])){
	@FANLY_BJH_CHECK(true);
}
//检测更新
if( $data = @FANLY_BJH_CHECK() ){
	$ver = @$data['ver'];
	$url = @$data['url'];
	$plugin_data = get_plugin_data( __FILE__ );
	if($ver > $plugin_data['Version']){
		echo '<div class="notice notice-warning"><p>百家号同步插件已经有新版本啦！ <a target="_blank" href="'.$url.'">立即查看</a></p></div>';
	}
}

$Fanly = get_option('Fanly_Baijiahao');//获取选项

//保存数据
if(isset($_POST['Fanly_Baijiahao'])){
	$Fanly				= get_option('Fanly_Baijiahao');//获取选项
    //处理数据
	$Fanly['app_id']	= trim(@$_POST['app_id']);
	$Fanly['app_token']	= trim(@$_POST['app_token']);
	$Fanly['Delay']		= trim(@$_POST['Delay']);
	$Fanly['reDelay']	= trim(@$_POST['reDelay']);
	$Fanly['Types']		= @$_POST['Types'];
	$Fanly['Context']	= trim(@$_POST['Context']);
	$Fanly['Sync']		= trim(@$_POST['Sync']);
	$Fanly['Copy']		= trim(@$_POST['Copy']);
	update_option('Fanly_Baijiahao', $Fanly);//更新选项
	echo '<div class="updated notice"><p>保存成功！</p></div>';
    
}

echo '<div class="wrap">';
echo '<h2>百家号同步</h2>';
echo '<form method="post">';
echo '<table class="form-table">';
echo '<tr valign="top">';
echo '<th scope="row">百家号 app_id</th>';
echo '<td><input type="text" name="app_id" value="'.@$Fanly['app_id'].'" /></td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<th scope="row">百家号 app_token</th>';
echo '<td><input type="text" name="app_token" value="'.@$Fanly['app_token'].'" /></td>';
echo '</tr>';
echo '<tr valign="top">
		<th scope="row">延迟时间</th>
		<td><input type="number" name="Delay" value="'.@$Fanly['Delay'].'" placeholder="请填写数字分钟数" /> 分钟（为空或0都将实时同步）</td>
		</tr>';
echo '<tr valign="top">
		<th scope="row">自定义延迟时间</th>
		<td><label><input value="true" type="checkbox" name="reDelay" '.checked( @$Fanly['reDelay'], 'true', false ).'> 开启，可针对文章独立设置</label></td>
		</tr>';
echo '<tr valign="top">
		<th scope="row">支持类型</th>
		<td>';
	$args = array('public' => true,);
	$post_types = get_post_types($args);
	foreach ( $post_types  as $post_type ) {
		if($post_type != 'attachment'){
			$postType = get_post_type_object($post_type);
			echo '<label><input type="checkbox" name="Types[]" value="'.$post_type.'" ';
			if(isset($Fanly['Types']) && is_array($Fanly['Types'])) {if(in_array($post_type,$Fanly['Types'])) echo 'checked';}
			echo '>'.$postType->labels->singular_name.' &nbsp; &nbsp; </label>';
		}
	}	
echo '</td></tr>';

echo '<tr valign="top">';
echo '<th scope="row">模块位置</th>';
echo '<td><select name="Context" class="postform">
<option value="advanced" '.selected( $Fanly['Context'], 'advanced', false ).'>高级</option> 
<option value="normal" '.selected( $Fanly['Context'], 'normal', false ).'>标准</option>
<option value="side" '.selected( $Fanly['Context'], 'side', false ).'>侧边</option>
</select></td>';
echo '</tr>';

echo '<tr valign="top">
		<th scope="row">是否默认同步</th>
		<td><label><input value="true" type="checkbox" name="Sync" '.checked( $Fanly['Sync'], 'true', false ).'> 勾选后默认同步，也可以在文章发布时选择是否同步！</label></td>
		</tr>';

echo '<tr valign="top">
		<th scope="row">是否添加版权提示</th>
		<td>
			<textarea name="Copy" cols="" rows="1" style="resize:both;width:100%;" placeholder="为空将不添加">'.stripslashes($Fanly['Copy']).'</textarea>
			<p>如：除非注明，否则均为'.get_bloginfo('name').'原创文章，转载必须以链接形式标明本文链接。(如遇文章审核出现推广提示，建议为空)</p>
		</td>
		</tr>';
echo '</table>';
echo '<p class="submit">';
echo '<input type="submit" name="Fanly_Baijiahao" id="submit" class="button" value="保存更改" />';
if(FANLY_BJH_CHECK()){
	echo '&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="check_updated" class="button" value="检测更新" />';
}else{
	echo '&nbsp;&nbsp;&nbsp;&nbsp;<a target="_blank" href="https://zhan.leiue.com/fanly-baijiahao.html">查看更新</a>';
}
echo '</p>';
echo '</form>';
echo '<p><strong>插件必看</strong>：<br>
1.百家号同步插件使用教程：<a target="_blank" href="https://zhan.leiue.com/fanly-baijiahao-use.html">https://zhan.leiue.com/fanly-baijiahao-use.html</a><br>
2.本插件其它相关问题至泪雪建站 <a target="_blank" href="https://zhan.leiue.com/fanly-baijiahao.html">百家号同步插件</a> 页面查看说明和留言反馈。</p>
</div>';
}