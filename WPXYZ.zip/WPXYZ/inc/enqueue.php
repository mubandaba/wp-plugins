<?php
//  function wpu_enqueue_sources(){
//      wp_enqueue_style ( 'site'      ,UTOOL_CSS_URL."wpxyz.css"        ,array(), false, 'all');
//  }
//  add_action('wp_enqueue_scripts' , 'wpu_enqueue_sources' , 2);
