# XML Sitemap &amp; Google News feeds

XML and Google News Sitemaps for WordPress to feed the hungry spiders. Multisite, WP Super Cache, Polylang and WPML compatible.

[https://wordpress.org/plugins/xml-sitemap-feed/](https://wordpress.org/plugins/xml-sitemap-feed/)

