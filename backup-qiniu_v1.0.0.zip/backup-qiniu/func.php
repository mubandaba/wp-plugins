<?php
require_once( 'php-sdk-master/autoload.php' );
require_once( 'Ifsnop/Mysqldump/Mysqldump.php' );
use Qiniu\Auth;
use Qiniu\Storage\UploadManager;
use Ifsnop\Mysqldump as IMysqldump;
	
//判断是否有子目录
function bzg_backup_qiniu_subdir( $path ) {
	$filelist = scandir( $path );
	$res = false;
	foreach($filelist as $file) {
		if ( $file == '.' || $file == '..') continue;
		$real_path = str_replace( DIRECTORY_SEPARATOR . DIRECTORY_SEPARATOR, DIRECTORY_SEPARATOR, $path . DIRECTORY_SEPARATOR . $file );
		if( is_dir( $real_path ) )
			$res = true;
	}
	return $res;
}
//遍历目录
function bzg_backup_qiniu_dirlist( $path, $dirlist = array(), $parent = '', $count = 0 ) {
	$count++;
	if ( is_dir( $path ) && $handle = opendir( $path ) ) {
		while ( false !== ( $file = readdir( $handle ) ) ) {
			if ( $file == '.' || $file == '..') continue;
			$real_path = str_replace( DIRECTORY_SEPARATOR . DIRECTORY_SEPARATOR, DIRECTORY_SEPARATOR, $path . DIRECTORY_SEPARATOR . $file );
			if ( is_dir( $real_path ) ) {
				$selected = '';
				if( in_array( $parent . $file, $dirlist ) ) $selected = ' checked="checked"';
				echo '<li><label><input type="checkbox" name="path[]" value="' . $parent . $file . '"' . $selected . ' />' . $file . '</label>';
				if( bzg_backup_qiniu_subdir( $real_path ) && $count < 3 ) {
					echo '<span class="dashicons dashicons-plus-alt"></span><ul class="child depth-' . $count . '">';
					bzg_backup_qiniu_dirlist( $real_path, $dirlist, $parent . $file . '/', $count );
					echo '</ul>';
				}
				echo '</li>';
			}
		}
		closedir($handle);
	}
}
//保留份数文件名后缀
function bzg_backup_qiniu_file_suffix($options) {
	if( ! $options['number'] || $options['number'] == 1 )
		return '';
	
	$timestamp = current_time( 'timestamp' );
	
	//一年中第几天
	$z = date( 'z', $timestamp );
	//一年中第几周
	$W = date( 'W', $timestamp );
	//不带前导0的月份
	$n = date( 'n', $timestamp );
	//星期几
	$w = date( 'w', $timestamp );
	
	$res = '';
	
	if( $options['number'] == 3 ) {
		switch( $options['cycle'] ) {
			case 'day':
				$res = '_' . ($z%3+1);
				break;
			case 'week':
				$res = '_' . ($W%3+1);
				break;
			case 'month':
				$res = '_' . ($n%3+1);
				break;
			default:
		}
	}
	
	if( $options['number'] == 7 ) {
		switch( $options['cycle'] ) {
			case 'day':
				$res = '_' . ($w+1);
				break;
			case 'week':
				$res = '_' . ($W%7+1);
				break;
			case 'month':
				$res = '_' . ($n%7+1);
				break;
			default:
		}
	}
	return $res;

}

// 打包目录
function bzg_backup_qiniu_addFileToZip( $path, $zip ) {
	$handler = opendir( $path );
	while( ( $filename = readdir( $handler ) ) !== false ) {
		if( $filename == '.' || $filename == '..' ) continue;
		$real_path = $path . '/' . $filename;
		if( is_dir( $real_path ) ) {
			bzg_backup_qiniu_addFileToZip( $real_path, $zip );
		} else {
			$zip->addFile( $real_path, str_replace( ABSPATH . '/', '', $real_path) );
		} 
	}
	
	closedir( $handler );
}

//备份
function bzg_backup_qiniu_start() {
	$options = get_option('backup_qiniu');
	$options = unserialize($options);
	if( $options['isdb'] == 'no' && $options['isfile'] != 'yes' )
		return;
	
	set_time_limit(0);
	
	$suffix = bzg_backup_qiniu_file_suffix( $options );
	$domain = preg_replace( '|https?://([^/]+)|', '$1', get_option( 'home' ) );
	$auth = new Auth( $options['AccessKey'], $options['SecretKey'] );

	//备份数据库
	if($options['isdb'] != 'no') {
		$error = '';
		try {
			$sql_temp = tempnam( sys_get_temp_dir(), 'qiniu_' );
			$dump = new IMysqldump\Mysqldump('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME, DB_USER, DB_PASSWORD);
			$dump->start($sql_temp);
		} catch (\Exception $e) {
			$error = $e->getMessage();
		}
		if( $error == '' ) {
			$fileSize = filesize($sql_temp);
			$handle = fopen($sql_temp, 'rb');
			$sqlContent = fread($handle, $fileSize);
			$file_temp = tempnam( sys_get_temp_dir(), 'qiniu_' );
			$file_temp = $file_temp . '.zip';
			$key = $domain . '_mysql' . $suffix . '.zip';
			$zip = new ZipArchive;
			if ( $zip->open( $file_temp, ZIPARCHIVE::CREATE ) === TRUE ) {
				$zip->addFromString( DB_NAME . '.sql', $sqlContent );
				$zip->close();
			}
			
			$token = $auth->uploadToken( $options['Bucket_Name'], $key );
			$upManager = new UploadManager();
			$upManager->putFile( $token, $key, $file_temp );

			fclose($handle);
			unlink($sql_temp);
			unlink($file_temp);
		}
	}
	
	//备份文件
	$paths = explode(',', $options['path']);
	if($options['isfile'] == 'yes' && ! empty($paths) ) {
		$zip = new ZipArchive();
		$file_temp = tempnam( sys_get_temp_dir(), 'qiniu_' );
		$file_temp = $file_temp . '.zip';
		$key = $domain . '_file' . $suffix . '.zip';
		if( $zip->open( $file_temp, ZipArchive::CREATE ) === TRUE ) {
			foreach( $paths as $path ) {
				if( ! $path ) continue;
				$path = ABSPATH .  '/' . $path;
				bzg_backup_qiniu_addFileToZip( $path, $zip );
			}
			$zip->close();
		}

		$token = $auth->uploadToken( $options['Bucket_Name'], $key );
		$upManager = new UploadManager();
		$upManager->putFile( $token, $key, $file_temp );

		unlink($file_temp);
	}
}
//定时任务
function bzg_backup_qiniu_cron() {
	$options = get_option('backup_qiniu');
	$options = unserialize($options);
	
	$the_time = current_time( 'timestamp' );
	$day = date('j', $the_time);
	$week = date('w', $the_time);
	
	$cron = false;
	switch( $options['cycle'] ) {
		case 'day':
			$cron = true;
			break;
		case 'week':
			if( $week == 1 ) $cron = true;
			break;
		case 'month':
			if( $day == 1 ) $cron = true;
			break;
		default:
			$cron = false;
	}
	
	if($cron) {
		bzg_backup_qiniu_start();
	}
}
?>