<p>
	<?php _e( 'XML sitemaps list the web pages of your site to tell search engines about the organization of your site content. Search engine web crawlers read this file to more intelligently crawl your site.', 'xml-sitemap-feed' ); ?>
</p>
