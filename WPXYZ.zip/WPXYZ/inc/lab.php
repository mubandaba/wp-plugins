<?php

function WPXYZ_add_submenu($name,$slug,$info='Prod by Wex'){
    CSF::createOptions( $slug, array(
        'framework_title'         => '<style>h4{font-size:13px!important;}ul{padding-left: 0px}</style><svg class="icon" style="width: 1em; height: 1em;vertical-align: middle;fill: currentColor;overflow: hidden;" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="5286"><path d="M512 512m-493.714286 0a493.714286 493.714286 0 1 0 987.428572 0 493.714286 493.714286 0 1 0-987.428572 0Z" fill="#0EDCC0" p-id="5287"></path><path d="M738.523429 460.544a35.547429 35.547429 0 0 0-30.390858-24.795429c-32.182857-4.827429-64.182857-10.422857-96.365714-14.701714a22.418286 22.418286 0 0 1-18.980571-14.445714c-13.531429-29.915429-27.428571-59.318857-41.618286-88.173714a53.394286 53.394286 0 0 0-12.873143-17.956572 34.889143 34.889143 0 0 0-54.418286 13.787429c-15.250286 31.195429-29.952 62.72-44.873142 94.244571a19.382857 19.382857 0 0 1-16.822858 12.324572c-31.414857 4.388571-62.829714 9.654857-94.244571 14.153142a37.595429 37.595429 0 0 0-33.645714 26.587429c-4.644571 15.067429 0.329143 31.451429 12.580571 41.362286 22.418286 22.454857 43.300571 44.873143 65.609143 66.194285a29.257143 29.257143 0 0 1 8.996571 29.074286c-6.070857 33.060571-11.227429 66.267429-16.713142 99.474286a38.144 38.144 0 0 0 39.789714 43.300571c5.668571-1.828571 11.154286-4.022857 16.493714-6.582857 28.598857-15.36 57.234286-30.976 85.504-47.030857a18.651429 18.651429 0 0 1 20.736 0c29.257143 16.603429 58.88 32.548571 88.393143 48.676571a33.645714 33.645714 0 0 0 37.924571-2.230857 35.913143 35.913143 0 0 0 15.250286-36.352c-5.046857-32.548571-9.764571-65.060571-16.274286-97.28a32.877714 32.877714 0 0 1 11.227429-33.645714 2674.029714 2674.029714 0 0 0 66.304-67.291429 36.022857 36.022857 0 0 0 8.411429-38.692571z" fill="#FFFFFF" p-id="5288"></path></svg>
                                  <span style="font-size:1rem;opacity: 0.8">'.$name.'</span>
                                  <small> '.$info.'</small>',
        'framework_class'         => '',
        'menWPXYZ_title'              => $name,
        'menWPXYZ_slug'               => $slug,
        'menWPXYZ_type'               => 'submenu',
        'menWPXYZ_parent'             => 'WPXYZ',
        'menWPXYZ_capability'         => 'manage_options',
        'menWPXYZ_position'           =>  null,
        'menWPXYZ_hidden'             =>  false,
        'show_sub_menu'           => true,
        'show_network_menu'       => true,
        'show_in_customizer'      => false,
        'show_search'             => false,
        'show_reset_all'          => false,
        'show_reset_section'      => false,
        'show_footer'             => false,
        'show_all_options'        => false,
        'sticky_header'           => false,
        'save_defaults'           => true,
        'ajax_save'               => true,


        // footer
        'footer_after'            => '<span style="opacity: 0.4;display: inline-block;margin-top: 0.8em">&copy;&nbsp;UTheme</span> ',
        'footer_credit'           => ' ',

        'database'                => '',
        'transient_time'          => 0,
        'contextual_help'         => array(),
        'contextual_help_sidebar' => '',
        'enqueue_webfont'         => true,
        'async_webfont'           => false,
        'output_css'              => true,
        'theme'                   => 'light',
        'class'                   => '',
        'defaults'                => array(),
    ) );
}
// 添加一个POST TYPE
function WPXYZ_add_posttype($name,$slug,$has_tax=true,$posttype_support= array( 'title','thumbnail','comments','editor'),$icon='dashicons-screenoptions',$secret=true){
    $labels = array(
        'name' =>$name,
        'singular_name' =>$name,
        'add_new' => '添加'.$name,
        'add_new_item' => '撰写新'.$name,
        'edit_item' => '编辑'.$name,
        'new_item' => '添加'.$name,
        'view_item' => '查看'.$name,
        'search_items' => '搜索'.$name,
        'not_found' => '未找到'.$name,
        'not_found_in_trash' => '回收站中没有'.$name,
        'all_items' => '所有'.$name,
        'archives' => $name.'存档',
        'insert_into_item' => '插入至'.$name,
        'uploaded_to_this_item' => '上传到本'.$name.'的',
        'featured_image' => '特色图片',
        'set_featured_image' => '设为特色图像',
        'remove_featured_image' => '移除特色图片',
        'use_featured_image' => '作为特色图像',
        'filter_items_list' => '过滤列表',
        'items_list_navigation' => '列表导航',
        'items_list' => $name.'列表',
        'menWPXYZ_name' => $name,
        'name_admin_bar' => $name
    );
    $args = array(
        'labels'               => $labels,
        'description'          => '',
        'public'               => true,
        'hierarchical'         => true,
        'exclude_from_search'  => false,
        'publicly_queryable'   => $secret,
        'show_ui'              => true,
        'show_in_menu'         => true,
        'show_in_nav_menus'    => true,
        'show_in_admin_bar'    => true,
        'menWPXYZ_icon'            => $icon,
        'menWPXYZ_position'        => 7,
        'capability_type'      => 'post',
        'capabilities'         => array(),
        'map_meta_cap'         => null,
        'supports'             => $posttype_support,
        'register_meta_box_cb' => null,
        'taxonomies'           => array(),
        'has_archive'          => true,
        'rewrite'              => true,
        'query_var'            => true,
        'can_export'           => true,
        'delete_with_user'     => null
    );
    register_post_type( $slug, $args);

    if($has_tax){
        $tax_labels = array(
            'name'              => $name.'分类',
            'singular_name'     => $name.'分类',
            'search_items'      => '搜索'.$name.'分类',
            'all_items'         => '所有'.$name.'分类',
            'parent_item'       => '该'.$name.'分类的上级分类',
            'parent_item_colon' => '该'.$name.'分类的上级分类',
            'edit_item'         =>  '编辑'.$name.'分类' ,
            'update_item'       =>  '更新'.$name.'分类' ,
            'add_new_item'      =>  '添加'.$name.'分类' ,
            'new_item_name'     =>  '新'.$name.'分类' ,
            'menWPXYZ_name'         =>  '分类' ,
        );
        $tax_args = array(
            'labels' => $tax_labels,
            'hierarchical' => true,
        );
        register_taxonomy( $slug.'_tax', $slug, $tax_args );
    }
}
// 添加一个通用POST TYPE
function WPXYZ_add_a_current_post_type($name,$slug,$icon='dashicons-screenoptions'){
    WPXYZ_add_posttype($name,$slug,true,array('title','thumbnail','comments','editor'),$icon,true);
}
// 添加一个只有title的POST TYPE
function WPXYZ_add_a_simple_post_type($name,$slug,$icon='dashicons-screenoptions'){
    WPXYZ_add_posttype($name,$slug,true,array('title'),$icon,true);
}
// 添加一个只有只能后台查看的POST TYPE
function WPXYZ_add_a_secret_post_type($name,$slug,$icon='dashicons-screenoptions'){
    WPXYZ_add_posttype($name,$slug,true,array('title'),$icon,false);
}

function WPXYZ_is_actived(){
    if(get_option('WPXYZ_status')=='actived'){
        return true;
    }else{
        return false;
    }
}
function WPXYZ_check_init(){
    $code = $_POST['code'];
    if(!isset($code)){
        $ret['msg'] = '未填写激活码';
        die();
    }
    $args = array(
        'action'=>'wpxyz_active_code',
        'code'=> $code,
    );
    $status = wp_remote_post( 'https://wx.wpxyz.com.cn/wp-admin/admin-ajax.php',array('body'=>$args));

    if ( is_array( $status ) && !is_wp_error($status)) {
        $body = $status['body'];
        $ret['code'] = $status = json_decode($body);
        if($status == 200){
            $ret['msg'] = '验证通过';
            update_option('WPXYZ_status','actived');
        }
        elseif ($status == 402){
            $ret['msg'] = '验证码错误';
        }else{
            $ret['msg'] = '非法请求';
        }
    }else{
        $ret['code'] = 404;
        $ret['msg'] = '远程服务器连接失败';
    }
    echo json_encode( $ret );
    die();

}
add_action('wp_ajax_check_init', 'WPXYZ_check_init');
add_action('wp_ajax_nopriv_check_init', 'WPXYZ_check_init');


function WPXYZ_plugin_upgrader( $transient ){

    if ( empty($transient->checked ) ) {
        return $transient;
    }

    if( false == $remote = get_transient( 'WPXYZ_upgrade_info' ) ) {

        $args = array(
            'action'=>'get_plugin_info',
            'site'=> get_bloginfo('url'),
            'id'=>'5'
        );
        $remote = wp_remote_post( 'https://utool.utheme.cn/wp-admin/admin-ajax.php',array('body'=>$args));

        if ( is_array($remote) && !is_wp_error( $remote ) && isset( $remote['response']['code'] ) && $remote['response']['code'] == 200 && !empty( $remote['body'] ) ) {
            set_transient( 'WPXYZ_upgrade_info', $remote, 60 );
        }

    }

    if( $remote ) {

        $remote = json_decode( $remote['body'] );

        // your installed plugin version should be on the line below! You can obtain it dynamically of course
        if( $remote && version_compare( WPXYZ_VERSION, $remote->version, '<' ) ) {

            $res = new stdClass();
            $res->slug = 'wpxyz';
            $res->plugin = 'wpxyz/wpxyz.php';
            $res->new_version = $remote->version;
            $res->package = $remote->src;

            $transient->response[$res->plugin] = $res;
        }

    }
    return $transient;
}
// add_filter('site_transient_update_plugins', 'WPXYZ_plugin_upgrader' );


function WPXYZ_switcher_action(){
    $id= $_POST['id'];
    $switchers = get_option('switchers');

    if($switchers[$id]){
        $switchers[$id] = false;
    }else{
        $switchers[$id] = true;
    }
    update_option('switchers',$switchers);
    $ret['code']= 200;
    echo json_encode($ret);
    die();

}
add_action('wp_ajax_WPXYZ_switcher','WPXYZ_switcher_action');

function WPXYZ_form_action(){
    $id= $_POST['id'];
    unset($_POST['action']) ;
    unset($_POST['id']) ;
    update_option($id,$_POST);
    $ret['code']= 200;
    echo json_encode($ret);
    die();
}
add_action('wp_ajax_WPXYZ_form_action','WPXYZ_form_action');


function WPXYZ_switcher($args){

    $id    =  $args['id'];
    $title =  $args['title'];
    $desc  =  $args['desc'];
    $default  = $args['default'];
    $switchers = get_option('switchers');

    if(!empty($default)){
        $switchers[$id]=$default;
        update_option('switchers',$switchers);
    }

    $checked = $switchers[$id]? 'checked' : '';

    echo <<<EOT

       <tr class="wex_option_item">
          <td>
              <div class="uk-margin-remove-bottom">
                  $title
              </div>
              <div class="uk-text-meta ">
                  <small>
                  $desc
                    </small>
              </div>
          </td>
          <td class="uk-text-right">
                <label class="">
                    <input data-id="$id" class="wex_option_item_switcher mui-switch mui-switch-anim" type="checkbox" $checked>
                </label>
          </td>
       </tr>
EOT;

}
function WPXYZ_input_form($args){

    $section_id    =  $args['id'];
    $section_title =  $args['title'];
    $section_options =  $args['options'];


    echo <<<EOT
<table class="uk-table uk-table-striped">
    <thead>
    <tr>
        <th>
            $section_title
        </th>
        <td class="uk-text-right">
            <button data-formid="$section_id" class="form_save uk-button uk-button-small uk-button-primary">保存</button>
        </td>
    </tr>
    </thead>
    <tbody id="$section_id">
EOT;

foreach ($section_options as $option){
    $setting_id = $option['id'];
    $option_title = $option['title'];
    $option_current_value= is_array(get_option($section_id))?get_option($section_id)[$setting_id]:'';
    $option_placeholder = $option['placeholder'] ? $option['placeholder'] : $option['title'];
    $input ='';
    $option_id = $section_id.'['.$setting_id.']';

    if($option['category']=='input'){
        $input = "<input id=\"$option_id\" data-id='$setting_id' value='$option_current_value' class=\"uk-input xyz_input\" type=\"text\" placeholder=\"$option_placeholder\" >";

    }elseif($option['category']=='textarea'){
        $option_row = $option['row'];
        $input =  "<textarea id=\"$option_id\" data-id='$setting_id' class='uk-textarea uk-border-rounded xyz_input' rows='$option_row' placeholder='$option_placeholder'>$option_current_value</textarea>";
    }
    // 判断如果有快捷按钮
    if(is_array($option['handles'])){
        $input .= '<div class="uk-margin-small-top">';
        foreach ($option['handles'] as $handle){
            $input .= xyz_handle($handle,$option_id).'&nbsp;';
        }
        $input .='</div>';
    }
    echo "<tr id=\"\">
        <td class=\"uk-width-1-3\">
            $option_title
        </td>
        <td>
            $input
         </td>
    </tr>
";
}

echo "</tbody></table>";

}


function xyz_handle($arg,$group){
    $id = $arg['id'];
    $title = $arg['title'];
    $color = $arg['color'];
    switch($color){
        case 'green':
            $colorClass = 'uk-label-success'; break;
        case 'orange':
            $colorClass = 'uk-label-warning'; break;
        case 'red':
            $colorClass = 'uk-label-danger'; break;
        default:
            $colorClass = '';
    }
    return "<span data-id='$id' data-group='$group' class=\"uk-label $colorClass xyz_handle\">$title</span>";
}
function WPXYZ_info(){
    add_menu_page(
        '小宇宙',
        '小宇宙',
        'administrator',
        'WPXYZ',
        '',
        'dashicons-admin-tools',
        999999
    );
    add_submenu_page( 'WPXYZ', '小宇宙', '小宇宙', 'administrator', 'WPXYZ', function(){
        include WPXYZ_PATH."/pages/home.php";
    });
    add_submenu_page( 'WPXYZ', '小宇宙', '优化加速', 'administrator', 'optimize', function(){
        include WPXYZ_PATH."/pages/optimize.php";
    });
    add_submenu_page( 'WPXYZ', '小宇宙', 'SEO工具', 'administrator', 'seo', function(){
        include WPXYZ_PATH."/pages/seo.php";
    });
    add_submenu_page( 'WPXYZ', '小宇宙', '扩展功能', 'administrator', 'store', function(){
        include WPXYZ_PATH."/pages/store.php";
    });
    add_submenu_page( 'WPXYZ', '小宇宙', '定时任务', 'administrator', 'dingshi', function(){
        include WPXYZ_PATH."/pages/dingshi.php";
    });
}
add_action( 'admin_menu', 'WPXYZ_info',1 );

