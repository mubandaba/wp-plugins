<?php
/**
 * Plugin Name: ThnBo
 * Description: ThnBo是一款针对WordPress开发的缩略图美化插件,为广大站长提供缩略图的美化便利
 * Author: 源分享
 * Author URI:https://code.jyace.cn
 * Version: 1.0.0
 * License: GPLv3 or later
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */

define('BASE_PATH', plugin_dir_path(__FILE__));

require_once(ABSPATH . 'wp-admin/includes/image.php');
require_once BASE_PATH . 'vendor/autoload.php';

use Grafika\Grafika;


(new THNBO)->init();

class THNBO {
    public function init() {
        add_action('post_updated', [$this, 'go'], 3, 10);
        add_action('admin_enqueue_scripts', [$this, 'import_js'], 9999);
        add_action('admin_menu', function () {
            add_options_page('ThnBo缩略图美化', 'ThnBo缩略图美化', 'manage_options', __FILE__, [$this, 'setting_page']);
        });
        add_filter(sprintf('%splugin_action_links_%s', is_multisite() ? 'network_admin_' : '', plugin_basename(__FILE__)), function ($links) {
            return array_merge(
                [sprintf('<a href="%s">%s</a>', network_admin_url(is_multisite() ? 'settings.php?page=thnbo%2Findex.php' : 'options-general.php?page=thnbo%2Findex.php'), '设置')],
                $links
            );
        });
    }

    /**
     * 插入附件
     *
     * @param $file string 附件的完整路径
     * @param $id int 对应的文章的ID
     *
     * @return int|WP_Error
     */
    private function insert_attachment($file, $id) {
        $dirs       = wp_upload_dir();
        $filetype   = wp_check_filetype($file);
        $attachment = array(
            'guid'           => $dirs['baseurl'] . '/' . _wp_relative_upload_path($file),
            'post_mime_type' => $filetype['type'],
            'post_title'     => preg_replace('/\.[^.]+$/', '', basename($file)),
            'post_content'   => '',
            'post_status'    => 'inherit'
        );
        $attach_id  = wp_insert_attachment($attachment, $file, $id);
        if ( ! function_exists('wp_generate_attachment_metadata')) {
            include_once(ABSPATH . DIRECTORY_SEPARATOR . 'wp-admin' . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'image.php');
        }
        $attach_data = wp_generate_attachment_metadata($attach_id, $file);
        wp_update_attachment_metadata($attach_id, $attach_data);

        return $attach_id;
    }

    /**
     * 在文章更新后开始处理缩略图
     *
     * @param $post_id int 文章ID
     * @param $tmp object 更新前的文章对象
     * @param $post object 更新后的文章对象
     *
     * @throws Exception
     */
    public function go($post_id, $post, $tmp) {
        $exist_thnbo        = get_post_meta($post_id, 'thnbo', true);
        $exist_thumbnail_id = get_post_meta($post_id, '_thumbnail_id', true);
        if ($exist_thnbo == $exist_thumbnail_id && ! empty($exist_thumbnail_id)) {
            return;
        }
        $super_out_path = '';

        if ($post->post_type === 'post') {
            if ( ! has_post_thumbnail($post_id)) {
                $post_content = get_the_content(null, null, $post);
                preg_match_all('/<img[^>]*?src="([^"]*?)"[^>]*?>/i', $post_content, $match);
                if ( ! key_exists(1, $match) || ! key_exists(0, $match[1]) || empty($match[1][0])) {
                    return;
                }
                $tmp_file_name = md5($match[1][0] . microtime()) . '.png';
                $out_path      = wp_upload_dir()['path'] . '/' . $tmp_file_name;
                copy($match[1][0], $out_path);

                $exist_thumbnail_id = $this->insert_attachment($out_path, $post_id);
                if (set_post_thumbnail($post_id, $exist_thumbnail_id)) {
                    $super_out_path = $out_path;
                }
            }

            $full_image_url = wp_get_attachment_image_src($exist_thumbnail_id, 'full');

            if ($full_image_url) {
                $tpls    = ['tpl/tpl_1.png', 'tpl/tpl_2.png', 'tpl/tpl_3.png', 'tpl/tpl_4.png', 'tpl/tpl_5.png'];
                $now_tpl = BASE_PATH . $tpls[mt_rand(0, 4)];

                $editor = Grafika::createEditor();

                $tmp_file_name = md5($full_image_url[0] . microtime()) . '.png';
                $tmp_file      = BASE_PATH . 'tmp/' . $tmp_file_name;
                copy($full_image_url[0], $tmp_file);
                $in       = $tmp_file;
                $out_path = wp_upload_dir()['path'] . '/' . $tmp_file_name;

                $editor->open($image1, $in);
                $thnbo_options = get_option('thnbo_options') ?: ['cut_type' => null];
                if ($thnbo_options['cut_type'] === '0' || $thnbo_options['cut_type'] === null) {
                    $editor->resizeFill($image1, 211, 125);
                } else {
                    $editor->resizeExact($image1, 211, 125);
                }
                $editor->save($image1, BASE_PATH . 'tmp/tmp.png');
                $editor->open($image1, $now_tpl);
                $editor->open($image2, BASE_PATH . 'tmp/tmp.png');
                $editor->blend($image1, $image2, 'normal', 1, 'top-left', 45, 40);
                $editor->save($image1, $out_path);

                if ( ! empty($super_out_path)) {
                    wp_delete_attachment($exist_thumbnail_id);
                }
                $attachment_id = $this->insert_attachment($out_path, $post_id);
                if (set_post_thumbnail($post_id, $attachment_id)) {
                    if ( ! empty($exist_thnbo)) {
                        delete_post_meta($post_id, 'thnbo');
                    }
                    add_post_meta($post_id, 'thnbo', $attachment_id, true);
                }
            }
        }
    }

    /**
     *  插件设置页注入JS
     */
    public function import_js() {
        wp_enqueue_script('layui_js', plugins_url('layui/layui.js', __FILE__), false, null, false);
        wp_enqueue_script('thnbo_start_js', plugins_url('layui/start.js', __FILE__), false, null, true);
    }

    /**
     * 设置页
     */
    public function setting_page() {
        if ( ! current_user_can('manage_options')) {
            wp_die('Insufficient privileges!');
        }

        wp_enqueue_style('layui_css', plugins_url('layui/css/layui.css', __FILE__));
        wp_enqueue_style('laobuluo_css', plugins_url('layui/css/laobuluo.css', __FILE__));

        $thnbo_options = get_option('thnbo_options') ?: ['cut_type' => null];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $thnbo_options['cut_type'] = sanitize_text_field($_POST['cut_type']);
            update_option('thnbo_options', $thnbo_options);

            echo '<div class="notice notice-success settings-error is-dismissible"><p><strong>设置已保存。</strong></p></div>';
        }
        ?>
      <div class="container-laobuluo-main">
        <div class="laobuluo-wbs-header" style="margin-bottom: 15px;">
          <div class="laobuluo-wbs-logo">
            <a>
              <img src="https://code.jyace.cn/wp-content/uploads/2020/09/1599017236-a14d43bd267f83a.png">
            </a><span class="wbs-span">ThnBo缩略图美化</span><span class="wbs-free">Free V1.0.0</span>
          </div>
          <div class="laobuluo-wbs-btn">
            <a class="layui-btn layui-btn-primary" href="https://code.jyace.cn/" target="_blank">
              <i class="layui-icon layui-icon-home"></i> 插件主页
            </a>
            <a class="layui-btn layui-btn-primary" href="https://code.jyace.cn/284.html" target="_blank">
              <i class="layui-icon layui-icon-release"></i> 插件教程
            </a>
          </div>
        </div>
      </div>
      <!-- 内容 -->
      <div class="container-laobuluo-main">
        <div class="layui-container container-m">
          <div class="layui-row layui-col-space15">
            <!-- 左边 -->
            <div class="layui-col-md9">
              <div class="laobuluo-panel">
                <div class="laobuluo-controw">
                  <fieldset class="layui-elem-field layui-field-title site-title">
                    <legend>
                      <a name="get">
                        设置选项
                      </a>
                    </legend>
                  </fieldset>
                  <form class="layui-form wpcosform" name="thnboform" method="post">
                    <div class="layui-form-item">
                      <label class="layui-form-label">图像裁剪</label>
                      <div class="layui-input-block">
                        <input lay-filter="choice" name="cut_type" type="radio" value="0" <?php
                        if ($thnbo_options['cut_type'] === '0' || $thnbo_options['cut_type'] === null) {
                            echo 'checked="TRUE"';
                        }
                        ?> title="居中裁剪">
                      </div>
                      <div class="layui-input-block">
                        <input lay-filter="choice" name="cut_type" type="radio" value="1" <?php
                        if ($thnbo_options['cut_type'] === '1') {
                            echo 'checked="TRUE"';
                        }
                        ?> title="强制缩放">
                      </div>
                      <div class="layui-input-block">
                        <div class="layui-form-mid layui-word-aux">
                          如果图片过大会按照你选择的方式进行裁剪
                        </div>
                      </div>
                    </div>
                    <div class="layui-form-item">
                      <label class="layui-form-label"></label>
                      <div class="layui-input-block"><input type="submit" name="submit" value="保存设置" class=" layui-btn"
                                                            lay-submit lay-filter="formDemo"/></div>
                    </div>
                    <input type="hidden" name="type" value="cos_info_set">
                  </form>
                </div>
              </div>
            </div>
            <!-- 左边 -->
            <!-- 右边 -->
            <div class="layui-col-md3">
              <div id="nav">
                <div class="laobuluo-panel">
                  <div class="laobuluo-panel-title">
                    商家推荐 <span class="layui-badge layui-bg-orange">专业源码站</span>
                  </div>
                  <div class="laobuluo-shangjia">
                    <a href="https://code.jyace.cn" target="_blank">
                      <img src="<?php echo plugin_dir_url(__FILE__); ?>layui/images/yfx.png">
                    </a>
                  </div>
                </div>
                <div class="laobuluo-panel">
                  <div class="laobuluo-panel-title">
                    扫码加QQ群
                  </div>
                  <div class="laobuluo-code">
                    <img src="<?php echo plugin_dir_url(__FILE__); ?>layui/images/qrcode.jpg">
                    <p>
                      扫码加入 <span class="layui-badge layui-bg-blue">站长交流</span> QQ群
                    </p>
                    <p>
                      <span class="layui-badge">优先</span> 获取插件更新 和 更多 <span
                              class="layui-badge layui-bg-green">免费插件</span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <!-- 右边 -->
          </div>
        </div>
      </div>
      <!-- 内容 -->
        <?php
    }
}
