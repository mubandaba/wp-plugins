<?php
// 防止本文件直接被访问
if (!defined('ABSPATH')) {
    exit;
}
wp_enqueue_style(  'uikit-style'        ,WPXYZ_STATIC_URL."uikit/css/uikit.min.css",   array(), false, 'all');
wp_enqueue_script( 'uikit'              ,WPXYZ_STATIC_URL."uikit/js/uikit.min.js",array() , false , false );
wp_enqueue_script( 'icon'               ,WPXYZ_STATIC_URL."uikit/js/uikit-icons.js",array() , false , false );
wp_enqueue_script( 'WPXYZ'         ,WPXYZ_JS_URL."WPXYZ.js",array() , false , false );


$site_url = get_bloginfo('url');
?>
<div class="uk-section">
    <div class="uk-container">
