<?php
function get_all_single_links(){
    $posts_to_show = 10000000000;
    $myposts = get_posts( "numberposts=" . $posts_to_show );
    $urls=[];
    if(is_array($myposts)){
        foreach( $myposts as $post ) {
            array_push($urls,get_permalink($post->ID));
        }
    }
    return $urls;
}

function get_all_archive_links(){
    $terms = get_terms('category', 'orderby=name&hide_empty=0' );
    $count = count($terms);
    $urls = [];
    if($count > 0) {
        foreach( $terms as $term) {
            array_push($urls,get_term_link($term, $term->slug));
        }
    }
    return $urls;
}
function get_all_page_links(){
    $mypages = get_pages();
    $urls=[];
    if(is_array($mypages)){
        foreach( $mypages as $page) {
            array_push($urls,get_page_link($page->ID));
        }
    }
    return $urls;
}
function baidu_api_push_array($api,$urls,$category){

    $result =  wp_remote_post($api,array('body'=>implode("\n", $urls)));
    $result_response_code = $result["response"]['code'];

    if($result_response_code == 200){

        $result_body =$result["body"];
        $result_body = json_decode($result_body);
        $success_num = $result_body->success ;
        $remain_num = $result_body->remain ;

        $ret = array(
            'status'       => $result_response_code,
            'successNum'  => $success_num,
            'remainNum'   => $remain_num,
        );
        if($category == 'fast'){

            $date = date("Y-m-d");
            $data = get_option($date.'_fast_submit');
            $data = $data ? $data : 0;
            $data = $data + $success_num ;
            update_option($date.'_fast_submit',$data);

        }elseif($category == 'current'){

            $date = date("Y-m-d");
            $data = get_option($date.'_current_submit');
            $data = $data ? $data : 0;
            $data = $data + $success_num ;
            update_option($date.'_currnent_submit',$data);
        }


    }else{
        $result_response_message = $result["response"]['message'];
        $ret = array(
            'status'         => $result_response_code,
            'error_message'  => $result_response_message,
        );
    }
    return $ret;
}
function baidu_api_push_string($api,$urls,$category){

    $result =  wp_remote_post($api,array('body'=>$urls));
    $result_response_code = $result["response"]['code'];
    $result_body =$result["body"];
    $result_body = json_decode($result_body);

    if($result_response_code == 200){

        $success_num = $result_body->success ;
        $remain_num = $result_body->remain ;

        $ret = array(
            'status'       => $result_response_code,
            'successNum'  => $success_num,
            'remainNum'   => $remain_num,
        );

        if($category == 'fast'){

            $date = date("Y-m-d");
            $data = get_option($date.'_fast_submit');
            $data = $data ? $data : 0;
            $data = $data + $success_num ;
            update_option($date.'_fast_submit',$data);

        }elseif($category == 'current'){

            $date = date("Y-m-d");
            $data = get_option($date.'_current_submit');
            $data = $data ? $data : 0;
            $data = $data + $success_num ;
            update_option($date.'_currnent_submit',$data);
        }

    }else{
        $result_response_message = $result_body->message;
        $ret = array(
            'status'         => $result_response_code,
            'message'         => $result_response_message,
        );
    }
    return $ret;
}

function wpxyz_baidu_api_save(){
    $api =  $_POST['api'];
    $api_category =  $_POST['category'];
    if(!isset($api)||!isset($api_category)){
        $ret = array(
            'status'  => 404,
        );
        echo json_encode( $ret );
        die();
    }
    if($api_category == 'fast'){
        update_option('wpxyz_baidu_fast_api',$api);
    }elseif($api_category == 'current'){
        update_option('wpxyz_baidu_current_api',$api);
    }
    $ret = array(
        'status'  => 200,
    );
    echo json_encode( $ret );
    die();
}
add_action('wp_ajax_baidu_api_save', 'wpxyz_baidu_api_save');

function current_api_submit_single(){
    $all_single_link = get_all_single_links();
    $api = get_option('wpxyz_baidu_current_api');

    if(!$api){
        $ret = array(
            'status'         => 408,
            'error_message'  => '缺少API',
        );
        echo json_encode( $ret );
        die();
    }
    if(!is_array($all_single_link)){
        $ret = array(
            'status'         => 409,
            'error_message'  => '缺少文章',
        );
        echo json_encode( $ret );
        die();
    }

    $ret = baidu_api_push_array($api,$all_single_link,'current');
    echo json_encode( $ret );
    die();

}
add_action('wp_ajax_current_api_submit_single', 'current_api_submit_single');

function current_api_submit_archive(){
    $get_all_archive_links = get_all_archive_links();
    $api = get_option('wpxyz_baidu_current_api');

    if(!$api){
        $ret = array(
            'status'         => 408,
            'error_message'  => '缺少API',
        );
        echo json_encode( $ret );
        die();
    }
    if(!is_array($get_all_archive_links)){
        $ret = array(
            'status'         => 409,
            'error_message'  => '缺少文章',
        );
        echo json_encode( $ret );
        die();
    }

    $ret = baidu_api_push_array($api,$get_all_archive_links,'current');
    echo json_encode( $ret );
    die();

}
add_action('wp_ajax_current_api_submit_archive', 'current_api_submit_archive');

function current_api_submit_page(){
    $get_all_page_links = get_all_page_links();
    $api = get_option('wpxyz_baidu_current_api');

    if(!$api){
        $ret = array(
            'status'         => 408,
            'error_message'  => '缺少API',
        );
        echo json_encode( $ret );
        die();
    }
    if(!is_array($get_all_page_links)){
        $ret = array(
            'status'         => 409,
            'error_message'  => '缺少文章',
        );
        echo json_encode( $ret );
        die();
    }

    $ret = baidu_api_push_array($api,$get_all_page_links,'current');
    echo json_encode( $ret );
    die();

}
add_action('wp_ajax_current_api_submit_page', 'current_api_submit_page');

function input_submit(){

    $all_links = $_POST['url'];
    $category = $_POST['category'];

    if(!isset($all_links)||!isset($category)){
        $ret = array(
            'status'         => 408,
            'error_message'  => '未提交URL',
        );
        echo json_encode( $ret );
        die();
    }
    if($category == 'current'){
        $api = get_option('wpxyz_baidu_current_api');
    }else{
        $api = get_option('wpxyz_baidu_fast_api');
    }
    $ret = baidu_api_push_string($api,$all_links,$category);
    echo json_encode( $ret );
    die();
}
add_action('wp_ajax_input_submit', 'input_submit');


