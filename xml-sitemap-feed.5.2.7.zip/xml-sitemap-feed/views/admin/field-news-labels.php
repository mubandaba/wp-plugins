<fieldset id="xmlsf_news_labels">
    <legend class="screen-reader-text"><?php _e('Source labels','xml-sitemap-feed'); ?></legend>
	<p class="description">
		<?php printf(__('Source labels inside a News Sitemap are no longer supported by Google News. To manage your site\'s labels, please go to the %s.','xml-sitemap-feed'),'<a href="https://news.google.com/publisher" target="_blank">'.__('Google News Publisher Center','xml-sitemap-feed').'</a>'); ?>
	</p>
</fieldset>
