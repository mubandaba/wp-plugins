=== ThnBo ===
Contributors: 源分享
Donate link: https://code.jyace.cn
Tags: thnbo
Requires at least: 3.5
Tested up to: 5.5.1
Requires PHP: 5.6
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

ThnBo是一款针对WordPress开发的缩略图美化插件,为广大站长提供缩略图的美化便利

== Description ==

ThnBo是一款针对WordPress开发的缩略图美化插件,为广大站长提供缩略图的美化便利

== Installation ==

安装后启用即可，该插件自动对所有发布和更新操作生效

== Changelog ==
= 1.0 =
1.方便快捷节省时间
2.发布-更新即可完善想要的效果
