﻿=== Plugin Name ===
Contributors: daxiawp
Donate link: http://www.daxiawp.com
Tags: auto save images, images, auto save, Remote images, External images, save images
Requires at least: 3.1
Tested up to: 3.8
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Automatically keep the remote picture to the local, and automatically generate thumbnails.自动保持远程图片到本地，并且自动生成缩略图。


== Description ==

Automatically keep the remote picture to the local, and automatically generate thumbnails. 

自动保持远程图片到本地，并且自动生成缩略图。

详情：[http://www.daxiawp.com/dx-auto-save-images.html](http://www.daxiawp.com/dx-auto-save-images.html)

== Installation ==

可以通过以下两种方法的其中一种来安装DX-auto-save-images插件：

1. 将下载的文件解压缩，然后将`dx-auto-save-images`文件夹 上传到 `/wp-content/plugins/`目录，在插件后台启用

2. 直接在后台-安装插件，搜索'dx-auto-save-images'，按照提示安装启用

== Frequently Asked Questions ==


== Screenshots ==

1. 后台截图1
1. 后台截图2

== Changelog ==

= 1.4.0 =
* 支持wordpress3.5
* 增加自动添加特色图像功能

= 1.3.1 =
* 修复bug

= 1.3.0 =
* 支持中文图片
* 可独立选择是否保存该文章的远程图片

= 1.2.0 =
* 增加后台选项，自定义是否生成缩略图

= 1.0.1 =
* 修复粘贴优酷等视频代码时出错

= 1.0 =
* 发布dx-auto-save-images插件



== Upgrade notice ==



== Arbitrary section 1 ==
